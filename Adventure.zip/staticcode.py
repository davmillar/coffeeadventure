# Created by David Millar
# Last Modified October 20, 2007

import os, readline, curses
from globals import *

# Scene Class - A scene is usually a room but can also be an event.
class Scene:
    # Initiation Function
    def __init__(self, num, opts, desc, short, action):
        self.num = num
        self.description = desc
        self.descriptionshort = short
        self.opts = opts
        self.action = action
        self.v = 0
    # Display Scene and Options
    def print_info(self):
        global playername
        if self.v == 0:
            print "\n" + self.description.replace('$name',playername)
            self.v = 1
        else:
            print "\n" + self.descriptionshort.replace('$name',playername)
        print "Choices:",
        for dir in self.opts.keys():
            print dir,
        if self.num in payphones and itemnum("PHONE CARD") > 0:
            print "PAYPHONE",
        print "(HELP for more)"
    # Add or Remove an Option
    def add_opt(self, name, n):
        self.opts[name] = n
        mapchanges.append([1,self.num,name,n])
    def rem_opt(self, name):
        del self.opts[name]
        mapchanges.append([2,self.num,name])
    # Change extra code status or description of scene
    def scr(self, mode):
        self.action = mode
        mapchanges.append([3,self.num,mode])
    def set_desc(self, text, short=0):
        if short == 0:
            self.description = text
        else:
            self.descriptionshort = text
        mapchanges.append([4,self.num,text,short])

# Popup class making use of curses 'windows' easier
class Popup:
    # Initiation Function
    def __init__(self,width,length,title=None):
        self.x = int((79 - width) / 2)
        self.y = int((23 - length) / 2)
        self.w = width
        self.l = length
        self.title = title
    def show(self):
        stdscr = curses.initscr()
        curses.noecho()
        self.scr = stdscr.subwin(self.l,self.w,self.y,self.x)
        self.scr.box()
        if self.title:
            self.scr.addstr(0,2,"[ "  + self.title + " ]")
        self.scr.refresh()
    def close(self):
        curses.echo()
        self.scr.erase()
        curses.endwin()
        clearscreen()
    def hr(self,row):
        self.scr.hline(row,1,curses.ACS_HLINE,self.w - 2)

# Returns Number of That Item You Have
def itemnum(i):
    global inventory
    if inventory.has_key(i):
        return inventory[i]
    else:
        return 0

# Add Item
def add_item(i,n):
    global inventory
    if inventory.has_key(i):
        inventory[i] += n
        if inventory[i] > 999:
           inventory[i] = 999
    else:
        inventory[i] = n

# Take Item
def rem_item(i,n):
    global inventory
    inventory[i] -= n
    if inventory[i] <= 0:
        del inventory[i]

# Show Inventory
def show_inv():
    global inventory
    print "\nYou have the following items in your sack:\nTRUSTY MINI ALL-IN-ONE DRINK MAKER",
    ik = inventory.keys()
    ik.sort()
    a = 0
    for i in ik:
        a = 1 - a
        if a == 0:
            print " | ",
        else:
            print "\n",
        print i.ljust(29),"X",str(inventory[i]).rjust(3,'0'),
    print "\nCHOINS X",choins

# Get Valid Input (0 for anycase, 1 for uppercase, 2 for integer)
def get_input(case):
    tmp = ""
    while tmp == "":
        tmp = raw_input("--> ")
    if case == 1:
        tmp = to_upper(tmp)
    elif case == 2:
        if tmp.isdigit():
            return int(tmp)
        else:
            return 0
    return tmp

# Converts a string to upper case
def to_upper(string):
    upper_case = ""
    for character in string:
        if 'a' <= character <= 'z':
            location = ord(character) - ord('a')
            new_ascii = location + ord('A')
            character = chr(new_ascii)
        upper_case += character
    return upper_case

# Clears the Screen
# If something goes awry it will just print 50 newlines to clear it as best as possible.
def clearscreen():
    if os.name == "posix":
        os.system("clear")
    elif os.name in ("nt", "dos", "ce"):
        os.system("CLS")
    else:
        print "\n" * 50