# Created by David Millar
# Last Modified October 20, 2007

import random, readline
from staticcode import *
from globals import *

# Recipe Book Function
def recipebook(lookup):
    global book
    if lookup == "":
        print "\nYou open your recipe book to the table of contents. What recipe are you looking for?"
        lookup = get_input(1)
    if lookup == "RANDOM" or lookup == "ANY":
        lookup = random.choice(book.keys())
    elif lookup == "BRAZILIAN CARWASH":
        print "\nYou flip to the page for BRAZILIAN CARWASH but realize that recipe should have been replaced by the CINNA SMACH recipe."
        if "BRAZILIAN CARWASH" in book.keys():
            book["CINNA-SMACH"] = [3,"CINNAMON SYRUP","CAPPUCCINO"]
            del book["BRAZILIAN CARWASH"]
    elif lookup == "COVER":
        print "\nYou close the book and stare dumbly at the cover, sideways:"
        print " ,---------. "
        print " ||    __  | "
        print " || ~()__) | "
        print " ||    U   | "
        print " `---------' "
        return
    elif lookup in ["TOC","TABLE","TABLE OF CONTENTS","CONTENTS","LIST","ALL"]:
        print "\nYou glance over the table of contents. You have recipes for the following:"
        b = book.keys()
        b.sort()
        for r in b:
            print "*",r,
        print "*"
        return
    elif lookup == "SYRUP":
        print "\n* SYRUP *"
        print "* SYRUP is an interesting drink. When mixing CANDY and WATER, you get SYRUP, but there are various types of SYRUP you can get. Sometimes it's a simple sugar syrup that dries to normal SUGAR, and sometimes you will get a flavored SYRUP. To make matters worse, you sometimes even get additional things like NUTS and SPRINKLES from mixing a SYRUP. Try it!"
        return
    elif book.has_key(lookup) == 0:
        print "\nYou thumb through the book but can't find anything marked",lookup+"."
        return
    recipe = book[lookup]
    print "\n*",lookup,"*"
    print "*",lookup,"is a ",skill[recipe[0]-1],
    print "drink to make. To make it, first you must load up your blender with",
    print recipe[1] + ". Then you must add",recipe[2],
    print "to the blender. Finally, press the button on the blender, and there you go! A delicious batch of",
    print lookup,"for you and your friends!"

# Mix a Drink
def mix_drink(dname):
    global book, inventory
    if dname == "":
        print "\nWhat drink would you like to make?"
        dname = get_input(1)
    if dname == "CRAPPUCCINO":
        print "\nYou're already full of COFFEE, MILK, and CRAP. You're so full of CRAP I don't think you need more CRAP."
    elif dname == "BRAZILIAN CARWASH":
        print "\nYou start to make a BRAZILIAN CARWASH but realize that recipe should have been replaced by the CINNA SMACH recipe."
        if "BRAZILIAN CARWASH" in book.keys():
            book["CINNA-SMACH"] = [3,"CINNAMON SYRUP","CAPPUCCINO"]
            del book["BRAZILIAN CARWASH"]
    elif book.has_key(dname) == 0:
        print "\nYou don't seem to know how to make a",dname,"but maybe you'll learn later. Or maybe not."
    elif 1:
        recipe = book[dname]
        if inventory.has_key(recipe[1]) == 0 or inventory.has_key(recipe[2]) == 0:
            print "\nYou don't seem to have the proper ingredients for a",dname,"- please consult your inventory and recipe book for details."
        else:
            rem_item(recipe[1],1)
            rem_item(recipe[2],1)
            if dname == "SYRUP":
                # Check if you need cinnmon syrup for a quest before going random
                if event[3] == 1 and itemnum('CINNAMON SYRUP') < 1 and itemnum('CINNA-SMACH') < 1:
                    stype = "CINNAMON SYRUP"
                elif event[8] == 4 and itemnum('BERRY SYRUP') + itemnum('BLOODY LARRY') + itemnum('PSYCH WARD') < 1:
                    stype = "BERRY SYRUP"
                else:
                    stype = random.choice(syrups)
                add_item(stype,1)
                r = random.randint(1,5)
                s = random.randint(1,3)
                # Randomize Additional Items/Check for tree mission
                if r == 4 or (event[8] == 1 and itemnum("NUTTY COFFEE") == 0 and itemnum("NUTS") == 0):
                    add_item('NUTS',s)
                    stype += " and NUTS"
                elif r == 5:
                    add_item('SPRINKLES',s)
                    stype += " and SPRINKLES"
                print "\nWith the whir of your blender, your",recipe[1],"and",recipe[2],"become",stype,"which is now in your inventory."
            else:
                add_item(dname,1)
                print "\nWith the whir of your blender, your",recipe[1],"and",recipe[2],"become a tasty",dname,"which is now in your inventory."

# Add Recipe to Book
def add_recipe(name, firIn, secIn, diff):
    global book
    if book.has_key(name) == 0:
        book[name]=[diff,firIn,secIn]