# Created by David Millar
# Last Modified October 20, 2007

import random, os, os.path, pickle, readline, curses, time
from staticcode import *
from globals import *

# Show Various Maps
def show_map(themap):
    global cdata, tiles
    if themap == "none":
        print "\nWhat map do you want to look at?"
        themap = get_input(1)
    if themap == "MAP":
        print "\nYes, we've established that you want a map. Which one? Maybe MAIN?"
        show_map("none")
    if themap == "MAIN" and itemnum("MAIN MAP") > 0:
        map = Popup(50,13,"Town Map")
        map.show()
        map.scr.addstr(2,2,"<-=======================================->")
        map.scr.addstr(3,16,",- * Farm       Truck")
        map.scr.addstr(4,7,"Shops * -+- * Library    Stop")
        map.scr.addstr(5,13,"*  |  * Club         *")
        map.scr.addstr(6,3,"Park []---+--+--+--------------|-* Store")
        map.scr.addstr(7,16,"|  *              |")
        map.scr.addstr(8,5,"Theatre * -|  Dance Club     `--------->")
        map.scr.addstr(9,2,"Apartments * -'                   Highway")
        map.scr.addstr(11,2,"Map Not to Scale")
        map.scr.getch()
        map.close()
    elif themap =="TREE" and itemnum("TREE MAP") > 0:
        map = Popup(34,15,"Tree Fortress Map")
        map.show()
        map.scr.addstr(2,26,"| |")
        map.scr.addstr(4,3,"1")
        map.scr.addstr(7,3,"2")
        map.scr.addstr(10,3,"3")
        map.scr.addstr(12,6,"| |")
        draw = []
        for a in cdata['maps'][2]:
            tmpdr = ["","",""]
            for b in a:
                c = tiles[b-1]
                tmpdr[0] += c[:5]
                tmpdr[1] += c[5:10]
                tmpdr[2] += c[10:]
            for b in tmpdr:
                draw.append(b)
        for i in range(0,9):
            map.scr.addstr(3+i,5,draw[i])
        map.scr.getch()
        map.close()
    elif themap =="RAIL" and itemnum("RAIL MAP") > 0:
        map = Popup(25,17,"Rail Yard Map")
        map.show()
        map.scr.addstr(2,7,"A    B    C")
        map.scr.addstr(4,11,"| |")
        map.scr.addstr(6,3,"1")
        map.scr.addstr(9,3,"2")
        map.scr.addstr(12,3,"3")
        map.scr.addstr(14,11,"| |")
        draw = []
        for a in cdata['maps'][0]:
            tmpdr = ["","",""]
            for b in a:
                c = tiles[b-1]
                tmpdr[0] += c[:5]
                tmpdr[1] += c[5:10]
                tmpdr[2] += c[10:]
            for b in tmpdr:
                draw.append(b)
        for i in range(0,9):
            map.scr.addstr(5+i,5,draw[i])
        map.scr.getch()
        map.close()
    elif themap =="RAIL BACK" and itemnum("RAIL MAP") > 0:
        map = Popup(25,18,"Go to it /b/ !")
        map.show()
        map.scr.addstr(2,7,"A   /B/   C")
        map.scr.addstr(4,11,"| |")
        map.scr.addstr(6,3,"1")
        map.scr.addstr(9,3,"2")
        map.scr.addstr(12,3,"3")
        map.scr.addstr(14,11,"| |")
        map.scr.addstr(15,8,"Some Cake")
        draw = []
        for a in cdata['maps'][1]:
            tmpdr = ["","",""]
            for b in a:
                c = tiles[b-1]
                tmpdr[0] += c[:5]
                tmpdr[1] += c[5:10]
                tmpdr[2] += c[10:]
            for b in tmpdr:
                draw.append(b)
        for i in range(0,9):
            map.scr.addstr(5+i,5,draw[i])
        map.scr.getch()
        map.close()
    elif 1:
        print "\nYou don't seem to have a map like that in your sack."
