# Created by David Millar
# Last Modified October 20, 2007

# Save filename
global sf
sf = ""
# Player Name
global playername
playername = ""
# Current Scene Number
global CurSceneNum
CurSceneNum = 0
# Events
global event
event = [0,0,0,0,0,0,0,0,0]

# Event List
# 0 Farmer Brown     1 Shell Game/Date    2 Revenge on Prep    3 Girlfriend
# 4 TJG Espresso     5 Scope/Truck Stop   6 Railway/Mandi      7 CB Radio
# 8 Squirrel/Wire

# Character Data
global cdata
cdata = {}
cdata['pwd'] = ['']
cdata['maps']=[[[1,1,7],[5,1,1],[1,7,1]],
[[7,1,1],[1,5,1],[1,1,7]],
[[3,2,4,2,5],[3,6,2,7,7],[4,1,4,6,1]]]
# Checks to see is the exotic coffee vendor is here
global ishere
ishere = 0
# Store Menus
global menus
# Payphone locations
global payphones
payphones = [4]
# Map Changes to Be Saved in the Save File and Applied Later at Load Time
global mapchanges
mapchanges = []
# Skill level descriptors for levels 1 to 5
global skill
skill = ['pretty easy','moderately difficult','quite hard','borderline insanely hard']
# Syrup Types Available via Blending Candy and Water
global syrups
syrups = ['CARAMEL SYRUP','CINNAMON SYRUP','BERRY SYRUP','SUGAR']
# Inventory and Recipe Book
global inventory
inventory = {'WATER':5}
global choins
choins = 50
global book
book = {'COFFEE':[1,'BEAN','WATER']}
# Map Tiles
global tiles
tiles=[' | |_ \___     ',
'  ___ /  _ | | ',
'___  _  \  | | ',
'_| | ___/      ',
'__________     ',
' | |  | |  | | ',
'_| |__   _ | | ']