#! /usr/bin/env python

# Created by David Millar
# Created August 4, 2007
# Last Modified October 20, 2007
# Version .102

version = ".102"

import random, os, os.path, pickle, readline, curses, time
from sys import stderr
from staticcode import *
from mapping import *
from drinks import *
from globals import *

# Load the Game from a Save File
def loadgame(fname,temppwd):
    # Open filename specified
    infile = open(fname,"r")
    # Define which pickled items are global and should be fed out to the game automagically
    global choins, inventory, book, event, cdata
    loader = pickle.load(infile)
    # THERE USED TO BE CODE HERE TO SUPPORT OLDER SAVES, BUT NOT ANYMORE!
    # Tests if v.101 or newer save file - cdata loader
    newcdata = {}
    if type(loader[5]) is str:
        newcdata['pwd'] = [loader[5]]
    else:
        newcdata = loader[5]
    # Tests for pre-.102 saves where visual maps were saved as mapchanges instead of cdata
    if newcdata.has_key('maps') == False:
        newcdata['maps'] = [[],[],[]]
    # Password Test
    if temppwd != newcdata['pwd'][0]:
        return False
    [tmpch, tmpin, tmpbk, change, evt] = loader[0:5]
    ts.close()
    print loader[1]
    time.sleep(5)
    print inventory
    time.sleep(5)
    print tmpin
    time.sleep(5)
    choins = tmpch
    inventory = tmpin
    print inventory
    time.sleep(5)
    book = tmpbk
    cdata = newcdata
    # Change event list rather than loading it so that the range is intact
    for e in range(len(evt)):
        event[e] = evt[e]
    # Reapply map changes and sky changes rather than loading the entire map
    for c in change:
        if c[0] == 1:
            map[c[1]].add_opt(c[2],c[3])
        elif c[0] == 2:
            map[c[1]].rem_opt(c[2])
        elif c[0] == 3:
            map[c[1]].scr(c[2])
        elif c[0] == 4:
            if len(c) < 4:
                c.append(0)
            map[c[1]].set_desc(c[2],c[3])
        # Applies changes to cdata maps to facilitate loading pre-.102 files
        elif c[0] == 6:
            if c[1] == 1:
                cdata['maps'][0] = c[2]
            elif c[1] == 2:
                cdata['maps'][2] = c[2]
            elif c[1] == 3:
                cdata['maps'][1] = c[2]
    infile.close()
    return 1

# Save the Game to a Save File
def savegame(fname):
    infile = open(fname,"w")
    #  !  Code here previously saved visual maps as mapchanges
    #  !  Now visual maps are part of cdata
    # Create Pickle list and save and close file
    picklelist = [choins, inventory, book, mapchanges, event, cdata]
    pickle.dump(picklelist,infile)
    infile.close()

# Choosing an Option from the Scene
def choice(Cs, Opt):
    phr = Opt.strip().split(" ")
    # Get rid of "GO" if used
    if phr[0] == "GO":
        if len(phr) == 1:
            return Cs.num
        del phr[0]
    # Substitute Abbreviations for Full Text
    if phr[0] in abbr.keys():
        phr[0] = abbr[phr[0]]
    if phr[0] == "MIX":
        if len(phr) > 1:
            if phr[1].isdigit() and phr[2]:
                for i in range(int(phr[1])):
                    mix_drink(" ".join(phr[2:]))
            else: 
                mix_drink(" ".join(phr[1:]))
        else:
            mix_drink("")
    elif phr[0] == "RECIPES":
        if len(phr) > 1:
            recipebook(" ".join(phr[1:]))
        else:
            recipebook("")
    elif phr[0] == "NEWPASS":
        global sf
        print "\nType it again to confirm."
        tmppass = get_input(0)
        if tmppass == phr[1]:
            cdata['pwd'] = phr[1]
            print "\nNew password and game saved."
            savegame(sf)
        else:
            print "\nPasswords don't match - sorry."
    elif Cs.num in payphones and phr[0] in ["PHONE","PAYPHONE"]:
        if len(phr) > 1:
            for i in range(int(phr[1])):
                phonecall(" ".join(phr[1:]))
        else:
            phonecall("")
    elif phr[0] == "MAP":
        if len(phr) > 1:
            show_map(" ".join(phr[1:]))
        else:
            show_map('none')
    elif phr[0] == "LOOK":
        map[Cs.num].v = 0
    elif phr[0] == "SAVE":
        global sf
        print "\nFile saved (hopefully successfully)."
        savegame(sf)
    elif phr[0] == "CLEARSAVE":
        global sf
        print "\nSave file cleared from server or local directory."
        os.remove(sf)
    elif phr[0] == "EXIT":
        return -1
    elif phr[0] == "HELP":
        print "\nEach scene comtains a list of possible commands for that location, but other universal commands exist, and some commands have shortcuts to make them easier to use."
        print "Additional Commands and Shortcuts:"
        abbrs = abbr.keys()
        abbrs.sort()
        for ab in abbrs:
            print ab, "|", abbr[ab]
    elif phr[0] in ["ABOUT","VERSION","CREDITS"]:
        #Start Curses Screen
        ts = Popup(79,23)
        ts.show()
        # Title/About Screen Text
        ts.scr.addstr(1,2,"COFFEE ADVENTURE v" + version)
        ts.scr.addstr(2,2,"By David Millar")
        ts.scr.addstr(4,2,"An interactive fiction game about:")
        ts.scr.addstr(5,4,"Being a Barista, Mixing Drinks, Exploring the World, and Other Nonsense.")
        ts.scr.addstr(6,2,"You might think you're an ordinary person, but you're actually...")
        ts.scr.addstr(7,4,"A COFFEE WARRIOR!")
        ts.hr(9)
        ts.scr.addstr(11,2,"This game has been created from scratch in Python.")
        ts.hr(19)
        ts.scr.addstr(21,2,"davmillar@gmail.com")
        ts.scr.addstr(21,63,"thegriddle.net")
        ts.scr.refresh()
        cred = {"Inspiration":["Adam LeFevre","Amanda LeFevre","Aaron Evangelisti","Emily Bischoff"],
                "Development":["Killernurd","Simon Donkers"],
                "Testing":["Workman 161","Lunar","Kidbomb","Joe"]}
        for group in cred.keys():
            ts.scr.addstr(13,2,group)
            a = 0
            for name in cred[group]:
                a += 1
                ts.scr.addstr(13+a,2,"- "+name)
            ts.scr.refresh()
            time.sleep(5)
            for i in range(0,5):
                ts.scr.addstr(13+i,2," "*40)
        ts.scr.addstr(13,2,"Press any key (enter) to continue with your game.")
        ts.scr.getch()
        ts.close()
    elif phr[0] == "INVENTORY":
        show_inv()
    elif Cs.opts.has_key(phr[0]):
        newnum = Cs.opts[phr[0]]
        ns = map[newnum]
        if ns.action == 1:
            moreaction(newnum)
        return newnum
    elif phr[0] == "EXOTIC":
        global ishere
        if ishere == 1:
            disp_menu(7,"Oh me! Oh my! That scent!|Can it be? What luck you have!|It's the magical exotic coffee cart!")
        else: 
            print "\nSorry, but the exotic coffee cart isn't here anymore."
    else:
        if phr[0] in ['NORTH','UP','DOWN','EAST','WEST','SOUTH']:
            print "\nI don't believe it's possible to go",phr[0],"from here."
        elif phr[0] == "ORDER":
            print "\nThere's nothing to order here."
        elif phr[0] == "USE":
            if "MAP" in phr:
                print "\nTo use a map, just type 'MAP <name of map>'. You don't need the word 'USE'."
            else:
                print "\nYou don't need to use an item - it will use itself when the moment is right."
        elif 1:
            print "\nI don't understand that."
    return Cs.num

# Make a Call to an NPC
def phonecall(who):
    global book, menus, inventory
    if who == "":
        print "\nWho would you like to call?"
        who = get_input(1)
    if who in ["ARMONDO","CANDY","STRIPPER","GANGSTER","MEXICAN","MEXICAN GUY","LATINO"]:
        if event[8] == 4 and book.has_key('PSYCH WARD') == 0:
            print "\nYou call up Candy and Armondo and say hello. 'Hey papi!' Candy says. 'What you need?' You explain that you're looking for a recipe for a love potion. 'Well, I know a coffee drink that makes people CRAZY like they in love. It's called a PSYCH WARD. You need a BLOODY LARRY and a NUTTY COFFEE to make it. You got that written down? OK, me and Armondo are going to East Side City to meet a trick - er - a friend at a motel. Call us if you need anything!' She hangs up."
            add_recipe('PSYCH WARD','NUTTY COFFEE','BLOODY LARRY',3)
        else:
            print "\nYou call up Candy and Armondo, and Armondo answers. You hear weird grunting sounds and Armondo says 'Hey bro, I'm kinda busy. Want to call back later?' He hangs up."
    elif who in ["FLO","TRUCK STOP"]:
        if book.has_key("SHELLY GROUNDS") and len(menus[4]) == 1:
            print "\nYou call Flo at the truck stop. 'Hey there ",playername+", what do ya need?' 'I need to make some smoother coffee. Can you save me some egg shells for the recipe?' 'Sure hun, just remind me every once in a while by giving me a call and I'll save them here for you. All I'll charge ya is 5 choins for washing them out. Take care!' She hangs up."
            menus[4].append([5,5,'EGG SHELLS'])
        else:
            print "\nYou call Flo at the truck stop, but the phone keeps ringing. She must be really busy right now. Try back later."
    elif who.find("GIRLFRIEND") != -1:
        print "\nYou call your ex-girlfriend's cell phone and she picks up and greets you with an overly cheerful hello. 'Guess what I did!' she exclaims! You sense something bad coming on. 'Remember when we were to gether and you told me I should kill my parents? Well, I tried to poison them, and now I'm in the mental ward. Just thought I would let you know!' She hangs up on you."
    else:
        print "\nYou dial a number but it ends up being some jerk you don't know."

############################################################################
# More Actions
# More: 1-10
def moreaction(thescene):
    global choins, inventory, event, playername
    if thescene == 3:
        if event[1] == 0:
            add_item("BEAN",1)
            choins -= 10
            map[2].add_opt("NORTH",4)
            map[2].set_desc("You are just outside a nasty looking movie theatre. Shady Latin gang members have a shell game set up nearby, and from previous experiences you know to avoid gambling like the plague.")
            event[1] = 1
        elif event[1] == 1:
            map[3].set_desc("You walk up to the gangsters and the boss guy says 'Get lost, fool!'")
            event[1] = 2
        elif event[1] == 3:
            map[3].set_desc("You walk up to the gangsters but they tell you to get lost.")
            if (inventory.has_key("ARMONDO'S NOTE") == 0):
                print "\nYou walk up to the gangsters and flash a picture of Candy in front of them. 'Woah, is that Candy?' the boss guy asks. I ain't seen her since high school!' He scribbles something on the back of a receipt for frozen wonton burrito meals, and you do the math and realize that he wants you to give candy the number."
                add_item("ARMONDO'S NOTE",1)
        elif event[1] == 4:
            print "\nYou see Candy with Armondo, and they wave you over. 'Hey, thanks for hooking us up again! And sorry Armondo took your choins in his little game, teehee!' She hands you 5 choins. 'Uhh, he took 10 choins from me, not fi-' 'SHUT UP RUBE!' Candy laughs at Armondo and kisses him on the cheek. 'We're going to the back seat of Armondo's car for coffee. See ya! They walk away and get into Armondo's car, which starts bucking around a bit. Then it suddenly starts up and leaves, opening the street to the south."
            choins += 5
            map[2].rem_opt("TALK")
            map[2].add_opt("SOUTH",15)
            map[1].add_opt("ORDER",16)
    elif thescene == 6:
        map[5].rem_opt("EAST")
        add_item('MAIN MAP',1)
        add_recipe('ICED COFFEE','COFFEE','ICE',1)
        add_recipe('ESPRESSO','COFFEE','BEAN',2)
        add_recipe('CAPPUCCINO','ESPRESSO','MILK',2)
        add_recipe('CREAMY COFFEE','COFFEE','MILK',1)
    elif thescene == 8:
        if event[1] >= 3 and (book.has_key("SYRUP") == 0):
            disp_menu(0,"'PROTIP!' 'Huh?' you respond.|'PROTIP! CANDY and WATER make various sugary SYRUPS|to add to your drinks!' Wow. Interesting.")
            add_recipe('SYRUP','CANDY','WATER',1)
        else:
            disp_menu(0)
# More: 11-20
    elif thescene == 11:
        if event[0] == 0:
            print "\nYou ask the farmer's wife what's going on, and she explains that her husband is severely exhausted. 'I would let him just get his sleep, but I'm a cruel woman and these cows need to be tended to. Can you get my husband something strong to drink so he can start selling milk again? If you need supplies, try the coffee shop in town.'"
            event[0] = 1
            map[5].add_opt("WEST",7)
        elif event[0] == 1:
            if inventory.has_key("ESPRESSO"):
                print "\n'Ah, that ESPRESSO will do the trick!' The wife promptly takes the high powered shot of coffee and jams it down Farmer Brown's throat. He wakes up INSTANTLY. 'Thanks for waking up my good for nothing husband. Here's some milk for your trouble. Come back soon and buy some more if you like it!'"
                map[11].set_desc("The farmer's wife stands around impatiently. Impatiently and angrily. But she has product to sell, so you ought to buy some.")
                add_item("MILK",3)
                rem_item("ESPRESSO",1)
                event[0] = 2
            else:
                print "\n'I don't think you have anything strong enough, kiddo. Come back with something high powered, like something that begins with E and ends with SPRESSO.'"
        elif 1:
             disp_menu(1)
    elif thescene == 14:
        if event[1] <= 1:
            event[1] = 3
            add_item("CANDY",1)
        elif event[1] == 3:
            if itemnum("ARMONDO'S NOTE") == 1:
                print "\n'Armondo? NO WAY! I remember how cute he was back in the day! I'm definitely gonna go see him! Thanks, and have some more candy!' She runs out and never looks back."
                pieces = random.randint(5,7)
                add_item("CANDY",pieces)
                event[1] = 4
                map[14].set_desc("There's no one here to talk to. Candy has gone off with Armondo somewhere.")
                map[14].set_desc("There's no one here.",1)
                map[13].rem_opt("TALK")
            else:
                map[14].set_desc("'You gonna find a guy for me honey?' Candy asks. You see the look of desperation in her eyes and decide to leave.")
    elif thescene == 16:
        disp_menu(2)
    elif thescene == 19:
        if event[2] == 0:
            print "\nDude, you have no idea what just happened. This dude ordered an iced venti americano and freaking THREW IT OVER THE COUNTER WHEN HE DIDN'T LIKE IT. You HAVE to help me get even dude. Can you help me? Unfortunately, I can't comp a lot of supplies, so here's 20 choins - all I got - I need you to make three ICED AMERICANOs and bring them back. Here's how to make one..."
            add_recipe("AMERICANO","ESPRESSO","WATER",2)
            add_recipe("ICED AMERICANO","AMERICANO","ICE",2)
            event[2] = 1
            choins += 20
        elif event[2] == 1 and itemnum("ICED AMERICANO") >= 3:
            print "\n'Alright dude, now you need to go outside and look for a guy that looks like a fricken loser. You know the type - preppy clothes, talking on his cellphone... I'm counting on you! If this goes well, the CS forums will rejoice!'"
            event[2] = 2
            d = random.choice([4,5,9,12,15])
            map[d].set_desc(map[d].description + " The jerk from the coffee shop is here.")
            map[d].set_desc(map[d].descriptionshort + " The jerk from the coffee shop is here.",1)
            map[d].add_opt('TALK',20)
            map[20].add_opt('BACK',d)
        elif event[2] >= 3:
            print "\n'Thanks dude! That was awesome! Here - have a MOCHA on me! Glad to hear that guy got what he deserved! Go forth and spread coffee to the world my brotha!'"
            add_item("MOCHA",1)
            map[19].scr(0)
    elif thescene == 20:
        if event[2] == 2:
            rem_item("ICED AMERICANO",3)
            event[2] = 3
            print "\nYou walk up to the jerk and say 'Hey, I heard you threw an ICED AMERICANO over the counter at the coffee shop just up the road.' The guy chuckles and replies 'Yeah, that loser doesn't know good coffee from crappuccino. What about it?' 'Well, maybe your cell phone would like to try it.' you say, and you throw all 3 drinks at the guy, getting his cell phone wet and electrocuting him! Oh man! What are you gonna do? Well, first you check his wallet for choins, then you run like hell."
            choins += random.randrange(35,65,5)
            map[20].scr(0)
# More: 21-30
    elif thescene == 22:
        if event[3] == 0:
            event[3] = 1
            print "\nYou sit down in a chair across from her. She's obviously drunk. She opens her mouth to speak, mumbles to herself a second, and then says 'Remember the day we met?' You pause for a second, but she starts up before you can talk again. 'Didn't you smash down my door, give Dudley a pig tail, and tell me I'm a wizard?' You stare at her like she's crazy, which she is. You glance at the window, and when you look back at her she's asleep. Her sleepiness reminds you of how tired you are, so you take a nap too.\n\nYou wake up hours later. She's still sitting there, but she's awake now and looks frustrated. 'God I have a horrible hangover.' You sigh. You know what's coming. 'Can you make me some coffee? And I mean the good stuff - a - a - a CINNA-SMACH!' 'WHAT THE HELL ARE YOU TALKING ABOUT?' You yell at her. 'Oh yeah, you can't make tasty coffee drinks. That's why I dumped you. Well, it just so happens that the swarthy Italian barista I dated the other night left his recipes in the pair of boxers he left here, so you can use those to fix me some coffee. And YOU HAD BETTER DO WELL. I still have those pictures from prom night!"
            add_recipe('CINNA-SMACH','CINNAMON SYRUP','CAPPUCCINO',3)
            add_recipe('BLOODY LARRY','BERRY SYRUP','ESPRESSO',3)
            add_recipe('ROLO POLO','CARAMEL SYRUP','MOCHA',3)
        elif event[3] == 1:
            if itemnum('CINNA-SMACH') > 0:
                event[3] = 2
                map[22].scr(0)
                choins += random.randrange(30,60,5)
                print "\nYou give her the drink and now she's off in a spicy land of magical cinnamon and coffee and such. In other words, she really likes it. You grab the pictures while she's having her happy time and throw them in the fireplace while she isn't looking. She satiated at the very least, and you have some new recipes. 'Why don't you sell those drinks out on the street? They suck less than you do. A LOT less...' she says, taking another sip. To prove her point, she throws some choins your way and then makes a weird wide-eyed sideways nod like she wants you to go away."
                rem_item("CINNA-SMACH",1)
            else:
                print "\n'Hurry back with my drink you loser.'"
    elif thescene == 24:
        if itemnum('ESPRESSO') > 0:
            print "\nThe kid grabs the ESPRESSO out of your hand wildly and yells 'THIS IS RELEVANT TO MY INTERESTS!' and downs the entire drink in one gulp. He starts running around and bouncing and crap, and now he is no longer blocking the path like a sleeping giant monster that requires an otherwise useless flute to wake up. Bit I digress. The kid bounces off first to the northeast and you hear a buzz and a snap and see what appears to be lightning shoot into the air. You can only assume that he has destroyed some sort of transformer and now the electrified fence near the railroad tracks has been de-electrified. Then you see the kid soaring through the air to the south in the direction of your ex-girlfriend's apartment building, most likely to get his next caffiene fix."
            map[24].scr(0)
            map[24].set_desc("There used to be a tired kid here, but now there are just park trails leading north and south. And the trees have bite marks all over them... hmm.")
            rem_item('ESPRESSO',1)
            map[9].add_opt("NORTH",33)
            map[24].set_desc("You're at a path in the park. It's not blocked.",1)
            map[24].add_opt("NORTH",25)
            map[21].add_opt("SOUTH",26)
            map[21].set_desc(map[21].description + " The apartment to the south is a bootleg coffee shop.")
            event[4] = 1;
    elif thescene == 26:
        r = random.randint(1,5)
        if r == 1:
            print "\nYou begin to comment on the cocoa mix packets, but then Landon sharpies over the Not For Resale label."
        if book.has_key("MOCHA") == 0:
            disp_menu(3,"'PROTIP!' 'Huh?' you respond.|'PROTIP! COCOA MIX and COFFEE makes a|MOCHA which is chocolatey and delicious!")
            add_recipe('MOCHA','COCOA MIX','COFFEE',1)
        else:
            disp_menu(3)
    elif thescene == 29:
        print "\nYou turn the telescope toward the red light district, then focus in further down the street and see one of those unnecessarily tall truck stop signs jutting into the air. It advertises showers, gas, apple pie, and COFFEE."
        if event[5] < 1:
            map[12].add_opt("EAST",30)
            event[5] = 1
# More: 31-40
    elif thescene == 32:
        disp_menu(4,"'Hi there hun, my name is Flo and I run this here diner and truck stop.|We serve all kinds of people and we even got a fancy pants bathroom with showers and all.|We even got all kinds of trucker stuff. Why don't you check out our shop, hun?'")
    elif thescene == 38:
        if event[6] == 0:
            print "'Hey there, I'm Mandi and I own this place!' says the girl at the counter. She's about to speak but you hear something bump under the counter. She reaches down and slaps something saying 'Shut up Chris!' and you hear a mumbled 'Sorry Mistress Mandi' from under the counter. 'Anyway, we serve a lot of drinks here but the carts only go up and down this stretch of tracks. The railroad company used to let us through their railyard in the west, but it's all screwed up thanks to a freakin tornado we had, and it's impossible to walk there cause the railbridge is dangerous on foot. Until we get that fixed, there's no way to get to the other towns. We do have a map of the area in question though, and we sell magical photocopies of it to anyone who wants one. Anywho, come back in a bit and we'll be open for business!"
            event[6] = 1
        elif event[6] == 1 and cdata['maps'][0] == [[2,4,7],[6,2,3],[1,7,4]]:
            disp_menu(5,"'Wouldn't you know it? The path to the other town is free to travel now!|I guess someone found some switches and fixed the tracks at the railyard.|Maybe now cart rental sales will heat up!'")
            event[6] = 2
        else:
            disp_menu(5,"Hi there, I'm Mandi!|I own this place!| ")
    elif thescene == 31:
        if event[7] == 0:
            print "\nYou overhear a conversation between a couple truckers.\n'Yeah, I'm stuck here until I get my CB radio fixed. Flo knows a guy up in the town northwest of here that's gonna fix it, but the bridge to get there is out and the only other way is a 5 hour detour.'"
            event[7] = 1
    elif thescene == 37:
        print "\nChoose a button to press in (column)(row) format, or X to stop monkeying around."
        button = ""
        while button != "X":
            # Get the button the player wants to push, and strip spaces and the words PRESS and PUSH if necessary
            button = get_input(1).lstrip('PRESUH ')
            if button == "X":
                break
            if len(button) != 2:
                print "\nI'm not sure which button would wanted to press."
            else:
                row = int(button[1:2])-1
                col = ord(button[0:1])-ord('A')
                if 0 <= row <= 2 or 0 <= col <= 2:
                    # Trick Map
                    square = cdata['maps'][1][row][col]
                    if 0 < square < 5:
                        square = (square % 4)+1
                    elif 4 < square < 7:
                        square = 11 - square
                    cdata['maps'][1][row][col] = square
                    # Real Map
                    square = cdata['maps'][0][row][col]
                    if 0 < square < 5:
                        square = (square % 4)+1
                    elif 4 < square < 7:
                        square = 11 - square
                    cdata['maps'][0][row][col] = square
                    print "\nYou push the button marked",button,"and hear clicking noises somewhere."
                else:
                    print "\nI'm not sure which button would wanted to press."
# More: 41-50
    elif thescene == 41:
        print "\n'Hey buddy, I'm freakin bored. Our weekly shipment didn't come in. If there's any stuff you wanna sell me, make an offer and we'll see how it goes. I might be able to throw some choins your way for items you have.' What do you want to sell? (X to stop.)"
        sellthings()
    elif thescene == 43:
        print "\n'Howdy",playername + ", I'm Adam, the ticket-taker, psychic, and Mandi's sister.",
        if event[6] <= 1:
            print "It's no use using these carts. They just go back and forth, and you don't look simple enough to find any fun in that.'"
        elif event[6] == 2:
            if itemnum("CART RENTAL") > 0:
                print "I see you have a CART RENTAL. I honestly don't see the need to keep buying them - I mean, hardly anyone buys these things so one pass should last you for a while. I remember your face, so I'll let you through free for a while, or at least 'til I forget what you look like.'"
                map[42].add_opt("WEST",44)
                rem_item("CART RENTAL",1)
                event[6] = 3
            else:
                print "It looks like the railway to the next town is open. I'll be cool and let you thorugh as many times as you want, but you need to buy at least one CART RENTAL from my sister."
        elif event[6] >= 3:
            print "Head on through, and have fun!'"
    elif thescene == 46:
        if event[6] == 3:
            print "\nYou walk up the the hermit and say 'Hey, what's going on? I thought the tracks were supposed to lead to North West City!' The hermit stops stirring his empty bowl and slowly tilts his head up to look at you. His solemn expression suddenly turns into an overly happy/cheesy smile and he says 'Are you the telephone repair man?' 'Excuse me?' 'I been waitin' to get my phone fixed for a long time. Could you fix it for me? I let you have my phone card if you get my phone line fixed. That way I don't need to hike all the way to the pay phone to make a call for more more wooden spoons and metal bowls. Just get some new WIRE and some ELECTRICAL TAPE and it's an easy job.'"
            map[25].set_desc("You're at the door of a cabin in the northlands of the city park. A sign on the cabin wall says 'Animal Dentist'. The office is now open.")
            map[25].add_opt("NORTH",50)
            map[21].add_opt("DOWN",52)
            event[6] = 4
        elif event[6] == 4:
            if event[8] == 3:
                if itemnum("ELECTRICAL TAPE") == 1 and itemnum("COPPER WIRE") == 1:
                    print "\nYou look around for the phone and find it on a table in the corner. You find a small broken piece of cord wih markings on it like it was hit repeatedly with a wooden spoon. You use the electrical tape and braces and crudely splice together the wires and listen on the phone until you achieve a dial tone. 'Thanks' says the hermit, handing you the phone card. 'Now if you do me one more favor, I'll fix the train tracks so you can go to North West City. All I need now is a LOVE POTION. Can you find one for me?' You reluctantly agree."
                    event[8] = 4
                    add_item('PHONE CARD',1)
                    rem_item('COPPER WIRE',1)
                    rem_item('ELECTRICAL TAPE',1)
                else:
                    print "\n'You get my phone fixed yet?' the hermit asks. 'Bring WIRE and ELECTRICAL TAPE.'"
            elif event[8] == 4:
                if itemnum("PSYCH WARD") == 1:
                    print "\n'Wow, thanks for all your help young man! I have the switch for the rail yard tracks outside right over here. As soon as you leave I'll make sure you're out there after the switch and flip it the right way. Have fun in North West City!' The hermit says. He downs the 'love potion' and starts going crazy, as the actual name 'PSYCH WARD' would suggest. As you leave, you see broken wooden spoons and splinters of wood flying through the air with dented metal bowls. You sure hope he can fix the track..."
                    event[8] = 5
                    rem_item('PSYCH WARD',1)
                    map[44].rem_opt('WEST')
                    map[44].add_opt('WEST',47)
                else:
                    print "\n'You get my love potion yet?' the hermit asks."
    elif thescene == 48:
        print "\nYou walk up to Tracey's table and she turns and smiles and you and says 'Ave it! Ave it all!' in a British accent. She pushes all manner of free items at you including several BEAN and lots of COFFEE."
        a = random.randint(5,7)
        add_item('COFFEE',a)
        add_item('BEAN',a)
        a *= 2
        while a < 15:
            b = random.randint(1,15-a)
            add_item(random.choice(['MILK','SUGAR','ICE','WATER','CANDY','AMERICANO','CAPPUCCINO']),b)
            a += b
        map[48].scr(0)
    elif thescene == 49:
        a = 1
        while a == 1: a = toast()
    elif thescene == 50:
        if event[6] == 4 and event[8] == 0:
            print "\nThe dentist is a man in his mid 20s and has short brown hair and a mustache and goatee. He gets up from his chair by the fireplace and says 'Hi there, how can I help you?' You explain your need for wire briefly and he responds. 'I had a bit of copper wire recently, but I had to make braces for a squirrel. He should be done with them by now. If you can lure him in, I should be able to take them off and give you the wire.'"
            event[8] = 1
        elif event[8] == 2 and itemnum("NUTTY COFFEE") > 0:
            print "\nYou lure the squirrel into the office with the NUTTY COFFEE and help the dentist get it into the operating room. After a 10 minute wait in the reception area, the doctor emerges looking beat-up and exhausted with scratches all over his arms and chest, but with a jumble of copper wire in his hand for you. After taking the wire, you help the dentist to his chair by the fireplace and he promptly slumps over and passes out."
            event[8] = 3
            add_item("COPPER WIRE",1)
# More: 51-60
    elif thescene == 51:
        if itemnum("NUTTY COFFEE") >= 1:
            event[8] = 2
            map[51].scr(0)
    elif thescene == 52:
        if itemnum("TREE MAP") == 0:
            print "\nYou scrounge the studio apartment and find a roll of electrical tape next to a book called 'Gamebox Modding for Losers'. You also find a weird RPG style map labeled TREE rolled up next to a stack of role playing books. You snag the items."
            add_item("TREE MAP",1)
            add_item("ELECTRICAL TAPE",1)
            map[52].scr(0)
    elif thescene == 53:
        if event[8] == 1 and itemnum("NUTTY COFFEE") > 0:
            event[8] = 2
    elif thescene == 54:
        print "\nPress a button, 1, 2, or 3 or 0 to exit."
        cmd = 4
        while cmd != 0:
            cmd = get_input(2)
            if 1 <= cmd <= 3:
                cdata['maps'][2][cmd-1].append(cdata['maps'][2][cmd-1][0])
                del cdata['maps'][2][cmd-1][0]
                print "\nYou press the button marked",cmd,
                if treemap == [[2,5,3,2,4],[6,2,7,7,3],[6,1,4,1,4]]:
                    map[53].rem_opt('PANEL')
                    map[53].add_opt('WEST',55)
                    print "and hear a loud humming buzzing noise and the panel regresses into the tree and a door slides open behind you in another tree."
                else:
                    print "and see an arrow pointing left light up next to the button, hear a buzz, and then the light goes off."
            else:
                print "\nYou smash your hand into the tree trying to push a button that isn't there."
    elif thescene == 56:
        map[56].scr(0)
        print "\nYou walk up to a Tree Elf to talk to him. He's extremely drunk - his disheveled green hat sits lopsided on his blonde hair and he's struggling to hammer a wooden sword into shape. He smells strongly of rum and seems to have wet himself. He looks up and is about to say something to you but then he passes out. When his face hits the table, a few pieces of parchment fall to the floor. You pick them up for him and, noticing a recipe for NUTTY COFFEE on top, copy it into your recipebook before letting the elf sleep."
        add_recipe("NUTTY COFFEE","COFFEE","NUTS",2)
# More: 61-70
    elif thescene == 62:
        disp_menu(6)
# More: 71-80

#######################################################################

# Use Toaster Oven - Returns 0 if user cancels
def toast():
    # Get item to toast
    print "\nWhat item would you like to put in the toaster oven? (X to stop)"
    item = get_input(1)
    if item in ['X','NONE']:
        return 0
    if itemnum(item) == 0:
        print "\nYou don't have that item to toast."
    # Choose the amount
    print "\nHow many",item,"do you want to toast?"
    amt = get_input(2)
    if amt <= 0:
        return 1
    # Check if item is toastable and modify it
    if item in toastitems.keys():
        newitem = toastitems[item]
    elif item[0:5] == "ICED ":
        newitem = item[5:]
    else:
        print "\nYou're about to toast the item, but you realize it's not a very good idea."
        return 1
    amt = max(amt, inventory[item])
    rem_item(item,amt)
    add_item(newitem,amt)
    print "\nYou put the",item,"in the toaster oven and a few minutes later you have",newitem+"."
    return 1

# Sell things to an NPC
def sellthings():
    sellitem = ""
    while sellitem != "X" and choins < 100:
        sellitem = get_input(1)
        if sellitem == "X":
            break
        amt = itemnum(sellitem)
        sellable = ['MILK','COCOA MIX','BEAN','WATER','RAIL MAP','BERRY SYRUP','CARAMEL SYRUP','CINNAMON SYRUP','SUGAR','CANDY']
        if amt == 0:
            print "\n'You don't have that to sell to me guy. Try something else."
        elif sellitem in ["ARMONDO'S NOTE","MAIN MAP","TREE MAP"]:
            print "\n'I don't have any use for that item. You hold onto it.'"
        elif sellitem == "BRAZILIAN CARWASH":
            if itemnum("BRAZILIAN CARWASH") > 0:
                print "\n'Wow! A BRAZILIAN CARWASH! They don't make those anymore! Hold onto those kid!'"
            else:
                print "\n'Hah! Nice try! You're bluffing. I haven't seen a BRAZILIAN CARWASH in years!'"
        elif book.has_key(sellitem) or sellitem in sellable:
            if sellitem in sellable:
                lv = .7
            else:
                lv = book[sellitem][0]
            max = int(5 * lv)
            min = -max
            price = int((3 ** (lv + 1)) + (random.randint(min,max)))
            print "'I can pay you",str(price),"each for those. You have",amt,"of those. How many do you want to sell me?"
            sellamt = get_input(2)
            choins += (sellamt * price)
            rem_item(sellitem,sellamt)
            print "'Alright, you just sold me",str(sellamt),sellitem,"for",str(sellamt * price),"choins.' Anything else?"
        else:
            print "\n'I don't have any use for that item. You hold onto it.'"
    if choins >= 100:
        print "\n'Sorry, I don't buy from rich yuppies like you who have money overflowing their pockets.'"

# Display Menu
def disp_menu(num, menumsg="It's fun to buy things!|Why not buy a ton of items?|That would be sweet!"):
    displaylist = []
    menuitems = menus[num]
    for i in range(0, len(menuitems)):
        b = menuitems[i]
        displaylist.append(str(b[1]) + " x " + str(b[2]).ljust(30) + str(b[0]).rjust(3) + "ch")
    displaylist.append("Nothing")
        
    # Initialize the Popup
    menupop = Popup(59,17,"Here's Our Menu")
    menupop.show()
    linemsg = menumsg.split("|")
    for i in range(3):
        menupop.scr.addstr(2 + i, 2, linemsg[i])
    menupop.scr.addstr(6, 2,"You scan the menu for items that you want to buy.")
    menupop.scr.addstr(7, 2, "Use the arrow keys and enter to select.")
    menupop.scr.addstr(8, 2, displaylist[0], curses.A_STANDOUT)
    for i in range(1, len(displaylist)):
        menupop.scr.addstr(i + 8, 2, displaylist[i])
    selected = 0
    while selected >= 0:
        ts.scr.refresh()
        key = menupop.scr.getch()
        menupop.scr.addstr(selected + 8, 2, displaylist[selected])
        if key == 65:
            selected -=1
            if selected == -1:
                selected = len(displaylist) - 1
        elif key == 66:
            selected += 1
            if selected == len(displaylist):
                selected = 0
        elif key == 10:
            if selected == len(displaylist) - 1:
                selected = -1
            else:
                menupop.scr.addstr(14, 2, " " * 45)
                menupop.scr.addstr(15, 2, " " * 45)
                buyitem = menuitems[selected]
                if num != 7:
                    maxallowed = (choins - (choins % buyitem[0])) / buyitem[0]
                    menupop.scr.addstr(14, 2, buyitem[2])
                    menupop.scr.addstr(15, 2, "How many? (Max " + str(maxallowed) + ")")
                    curses.echo()
                    tmpamt = menupop.scr.getstr(15, 23, 3)
                    if tmpamt.isdigit():
                        buyamt = int(tmpamt)
                    else:
                        buyamt = 0
                    curses.noecho()
                else:
                    buyamt = 1
                menupop.scr.addstr(14, 2, " " * 45)
                menupop.scr.addstr(15, 2, " " * 45)
                if (buyitem[0] * buyamt) <= choins and buyamt > 0:
                    choins -= (buyitem[0] * buyamt)
                    if num != 7:
                        add_item(buyitem[2],buyitem[1] * buyamt)
                        menupop.scr.addstr(14, 2, " " * 45)
                        menupop.scr.addstr(15, 2, "Hope you're happy with the " + buyitem[2] + ".")
                        selected = 0
                    else:
                        menupop.scr.addstr(14, 2, "Hope you're happy with the " + buyitem[2] + ".")
                        menupop.scr.addstr(15, 2, "You greedily gulp down the delicious " + buyitem[2] + " and begin to feel a mystical feeling!")
                        cdata['exotic'][0] = int(((random.random() * 1.5) + .25)*buyitem[0])
                        cdata['exotic'][1] = buyitem[2]
                        selected = -1
                else:
                    menupop.scr.addstr(15, 2, "You can't buy that many.")
                    selected = 0
        menupop.scr.addstr(selected + 8, 2, displaylist[selected], curses.A_STANDOUT)
    ts.close()

# The Map of the Game
map = [Scene(0,{'NORTH':1},"You are in a friggen bathroom at the movie theatre. It smells like nasty, evil stuff in here. It's so, so, so gross. Worst hell hole you ever saw. You get the sudden urge to go north and east to the outside and gamble.","You're at the movie theatre bathroom.",0),
       Scene(1,{'SOUTH':0,'EAST':2},"You are in the lobby of the nasty movie theatre. The stench from the mens' room invades the air rendering the smells of popcorn and snacks from the snack bar useless.","You're at the movie theatre.",0),
       Scene(2,{'WEST':1,'TALK':3},"You are just outside a nasty looking movie theatre. Shady characters lurk nearby. The characters happen to be three Latin gang member types who have set up a typical shell game. The cigar smoking boss of the operation has the typical machismo image There's a big group of people walking around the street in the north.","You're outside the movie theatre near thugs.",0),
       Scene(3,{'BACK':2},"Macho Man says 'Alright, hand over 10 choins.' 'Choins?' you ask. 'Yeah, choins. The H is invisible like how in some words letters are silent. Didn't you go to public school?' You hand over the choins and he places a bean under one of three cups. After some sliding around with the cups, you successfully fail at correctly picking the right cup. 'Here kid,' the guy says as he hands you the bean. 'Consolation prize.' The crowd in the street to the north has started thinning out and one of the gangsters off to the side chuckles and says 'Go back to the library where you belong, fool!'","Scram, kid!",1),
       Scene(4,{'NORTH':5, 'SOUTH':2, 'EAST':12, 'WEST':17},"You're on a street downtown. Everything is kinda dirty and creepy around here. Graffiti covers just about everything. A badly defaced sign points north and says 'Public Library Ahead'.","You're at a dirty, creepy street downtown.",0),
       Scene(5,{'SOUTH':4, 'EAST':6, 'NORTH':9},"You're on a dirty street downtown. The public library is on the east side of the street. Hustling and bustling people go in and out of various buildings, mostly shops, while others walk up and down the street.","You're downtown near shops and the library.",0),
       Scene(6,{'WEST':5},"You're inside the public library. Notices all over warn that the library will be closing shortly for a long-term renovation plan and explain some mumbo jumbo about inter library loans. In the short amount of time you have, you copy down some coffee recipes from a book in the nonfiction section. On the way out you grab one of the free maps they had. You use a Sharpie to write MAIN in big bold letters on the map.","You're at the library which is under renovation.",1),
       Scene(7,{'EAST':5, 'ORDER':8},"You're in a trendy but old looking coffee shop. It's not the kind of coffee shop that posers would know about - only the social outcasts and those in the 'know' would find it. The old-school wooden bar is rough but polished. Behind the bar sits shelves of various flavored syrups and powders for coffee drinks. A couple people sit alone at small tables with their laptops while a few groups of people sit together and chat at wall or corner tables.","You're in an old coffee shop downtown.",0),
       Scene(8,{'BACK':7},"You finish up your order and get ready to be on your way.","You're at the counter in a shop.",1),
       Scene(9,{'SOUTH':5, 'EAST':10},"You're on a street near the edge of the downtown area. Shops are starting to thin out into a typical neighborhood where people live. An electric fence guards a set of train tracks are along the north edge.","You're at the edge of town.",0),
       Scene(10,{'WEST':9,'TALK':11},"You're in the backyard of a home in the middle of the city. A farmer type guy is half asleep and his wife is standing near him over by the fence. Cows graze in the patchy yard.","You're at a farm-like house.",0),
       Scene(11,{'BACK':10},"The farmer's wife stands around impatiently. Impatiently and angrily.","You're standing in front of the farmer's wife.",1),
       Scene(12,{'WEST':4,'NORTH':13,'SOUTH':27},"You're downtown in the red light district. The red light has stopped traffic, but you're on foot, so you can visit plenty of the fine local establishments.","You're in the red light district.",0),
       Scene(13,{'SOUTH':12, 'TALK':14},"You're in a strip club. It's not very lively - it's probably the wrong time of day for serious stripping to go on. One of the strippers is sitting at a booth drinking something.","You're in the strip club.",0),
       Scene(14,{'BACK':13},"'Hey, my name is Candy. Here, have a piece of candy. I Like shaking my stuff and giving out candy. But I really wish I could find a sweet guy so I can stop stripping. Let me know if you find a decent guy. I don't want a thug or a gangster or anything...","You're standing in front of Candy.",1),
       Scene(15,{'NORTH':2,'EAST':21},"You're in the south part of downtown. It's starting to fade from the ghetto to the preppy rich kid part. You shudder involuntarily because your ex-girlfriend's apartment is on the east side of the street.","You're outside the apartment building.",0),
       Scene(16,{'BACK':1},"You're at the snack bar of the movie theatre. Overpriced crap!!! Run!","You're at the theatre snack bar.",1),
       Scene(17,{'EAST':4,'NORTH':18,'WEST':23},"You're in the town square downtown and there's a giant fountain in the middle. Unusual looking shops, some of which are closed for the weekend or don't open for a while, line the square and benches and trees and flowers adorn the area.","You're at the town square.",0),
       Scene(18,{'SOUTH':17, 'TALK':19},"You walk into a little coffee shop, quite like the millions of others around town. Unlike the others, a friend of yours works here. He's waiting on a few customers but probably has time to talk.","You're in a friend's coffee shop.",0),
       Scene(19,{'BACK':18},"Looks like Jared is counting on you...","You're in front of your friend Jared.",1),
       Scene(20,{},"The guy's body writhes in pain at the electrocution. Best not stick around...","You're in front of an electrocuted jerk.",1),
       Scene(21,{'WEST':15,'TALK':22},"You're in your ex-girlfriend's apartment. She's sitting on the couch after having let you in hesitantly.","You're in your girlfriend's apartment.",0),
       Scene(22,{'BACK':21},"She sits there waiting for you to do something with your life, $name, you loser.","You're sitting across from your girlfriend.",1),
       Scene(23,{'EAST':17,'NORTH':24,'WEST':28,'SOUTH':51},"You're in the garden area of the big downtown park. Half of the town square's fountain extends into the grass and flowery area here and paths lead off into several directions.","You're in the garden near downtown.",0),
       Scene(24,{'SOUTH':23},"There's a small child here wearing a giant nametag that says 'TJG92'. He won't respond to you and he looks tired like he has been impersonating a programmer all night.","You're at a blocked path in the park.",1),
       Scene(25,{'SOUTH':24},"You're at the door of a cabin in the northlands of the city park. A sign on the cabin wall says 'Animal Dentist'. The office is currently closed.","You're outside the animal dentist's cabin.",0),
       Scene(26,{'NORTH':21},"You're across the hall from your girlfriend's apartment at a coffee shop out of some guy's apartment. A crudely drawn sign says you're at 'Landon F's Coffee Emporium' and Landon comes out of the dark back room with his freshly hand-ground beans.","You're in Landon's apartment.",1),
       Scene(27,{'NORTH':12,'TALK':48},"You're in a night club. The music sucks, like a Coke can and a few Latin women inside a plane's engine room. In the corner, there's a raver girl with pink hair and piercings sitting at a table with a banner and various items. The banner says 'Tracey's Free Stuff'.","You're in a night club.",0),
       Scene(28,{'EAST':23,'SCOPE':29},"You're on top of a big hill near the garden in the park. The hill is completely devoid of trees, and it seems as though someone left a telescope up here. It's tripod is planted firmly to the ground and the adjustment levers are a bit funky to say the least.","You're at the telescope.",0),
       Scene(29,{'BACK':28},"You finish using the telescope and set it back to 0 degrees.","You're right up close to the telescope.",1),
       Scene(30,{'WEST':12,'NORTH':31,'EAST':39},"You're in the middle of a busy part of town with fast cars and even faster food. The freeway on-ramp is to the south, to the east is the end of the road and a convenience store, and to the North is a truck stop.","You're in the busy area downtown.",0),
       Scene(31,{'SOUTH':30,'TALK':32},"You're in a truck stop. Truckers sit at the bar, or at tables in small groups chuckling over COFFEE or eating various suspicious foods and big slices of cherry pie. A waitress named Flo makes her rounds at the tables and behind the counter taking orders to the cook in back.","You're in the truck stop.",1),
       Scene(32,{'BACK':31},"You're done at the counter for now.","You're at the truck stop counter.",1),
       Scene(33,{'SOUTH':9,'EAST':34},"You're on a set of railroad tracks along the north border of the town, leading east and west. There's a train bridge to the west, but you can walk along the tracks to the east.","You're at the train tracks.",0),
       Scene(34,{'WEST':33,'SOUTH':35,'UP':42},"You're at a weird looking combination train station and coffee shop called 'Mandi's Caffination Station'. There are tracks leading west, a platform leading up, and to the south is the inside of the shop and station.","You're outside Mandi's shop.",0),
       Scene(35,{'NORTH':34,'DOWN':36,'TALK':38},"You're inside 'Mandi's Caffination Station'. Weird looking people adorn the shop like decapitated dolls on a Christmas tree. The freaks come in all shapes and sizes, from monochrome goths to rainbow tinted witches. There's a wooden counter alongthe side of the shop selling various items as well as hand-cart rentals for the tracks outside. Stairs lead down to a restricted part of the shop.","You're in Mandi's caffination Station.",0),
       Scene(36,{'UP':35,'PANEL':37},"You're in a small control room underneath 'Mandi's Caffination Station'. The room is half caved in, as if the shacklike building above was built atop the rubble of an abandoned station. The room is half steampunk style and half 'look at me I played Myst in 1993' style. There is a set of 9 buttons on the wall in a 3 by 3 square with labels A through C across the top and 1 through 3 along the left.", "You're in the control room.",0),
       Scene(37,{'BACK':36},"You finish pushing buttons and step back from the panel.","You're at a control panel.",1),
       Scene(38,{'BACK':35},"You finish talking to Mandi and step back from the counter.","You're at the counter in Mandi's shop.",1),
       Scene(39,{'WEST':30,'EAST':40},"You're in the parking lot of the local convenience store. Two shady looking guys stand outside swearing. Through the glass windows you can see a really fat guy working behind the counter and some lady in front ofthe counter carrying on a boring conversation with him.","You're outside a convenience store.",0),
       Scene(40,{'WEST':39,'TALK':41,'TOAST':49},"You're inside the convenience store. There's a lady talking to the clerk, who looks bored and fat. He seems shady though and might be able to do some business dealings with you.","You're in the convenience store.",0),
       Scene(41,{'BACK':40},"You're at the convenience store counter blocking a convo between the fat guy and the crazy woman.","You're at the convenience store counter.",1),
       Scene(42,{'DOWN':34,'TALK':43},"You're on a raised train platform where hand carts are rented out for use on the old tracks. A ticket taker mans a make shift gate to keep hooligans from getting in without a rental pass. Stairs lead down to the other set of tracks near the caffination station, and behind the gate, tracks for the carts go west.","You're on a raised train platform.",0),
       Scene(43,{'BACK':42},"You're at the ticket counter of the station next to Mandi's Caffination Station.","You're at the ticket counter.",1),
       Scene(44,{'EAST':42,'WEST':45},"You're on a hand cart. To the west is the rail yard with tons of crazy track switches and curves and lots of crazy machinery. To the east is the station platform for Mandi's Caffination Station.","You're on a hand cart on the tracks near Mandi's Caffination Station.",0),
       Scene(45,{'EAST':44,'TALK':46},"You're in the hermit's shack southwest of the rail yard. The hermit is here mixing an empty metal bowl with a wooden spoon making clink-clink-clink noises.","You're in the hermit's shack.",0),
       Scene(46,{'BACK':45},"You finish talking to the hermit and he goes back to mixing his empty metal bowl with his wooden spoon.","You're at the hermit's table in his shack.",1),
       Scene(47,{'EAST':44,'NORTH':57},"You're at the abandoned 6th street station in North West City. Dusty windows and and broken wooden doors make the station look even older. Abandoned boxcars and hand carts line the tracks. A rusty old metal gate leads  up a ramp north to street level.","You're at the 6th street station.",0),
       Scene(48,{'BACK':27},"You're in front of Tracey's table of free stuff. She's dancing to the music saying things like 'Yeah! Proper phat tunes man!' There's a sign on the table that says 'Stuff's all gone. Unlucky Kentucky!'","You're at Tracey's Free Stuff table.",1),
       Scene(49,{'BACK':40},"You finish using the toaster oven and back away in case it decides to catch fire.","You're at the convenience store toaster oven.",1),
       Scene(50,{'SOUTH':25},"You're inside the animal dentist's office. The dentist sits in a big Victorian style chair in front of the fireplace smoking a pipe. The chair is a deep blood red color and tackily matches the metal and pleather 80s style waiting room chairs. A big wooden door to the west leads to the off-limits operating room where the dentist does his business. To the south is the door leading outside.","You're inside the animal dentist's office.",1),
       Scene(51,{'NORTH':23,'SOUTH':53},"You're in the park in an area with a light amount of trees. Various wild type animals abound here - the occasional bunny, birds, insects, and a few squirrels.","You're in the city park near some wild animals.",0),
       Scene(52,{'UP':21},"You're in the apartment of a total nerd. It's a basement studio apartment with a half-made bed and dirty clothes on the floor. There are manga posters and video game equipment everywhere. A note on the cluttered desk in the room says 'Gone fencing, bbl - Aaron'.","You're in Aaron's apartment.",1),
       Scene(53,{'NORTH':51,'PANEL':54},"You are in the south end of the city park where the trees are older and bigger and the light is scarce and the land is dark. The path here ends in a small clearing with a bit of light gleaming down. It continues back north toward the main park. There are 4 buttons on a panel on the side of a tree here.","You're in the south end of the park.",0),
       Scene(54,{'BACK':53},"You finish tinkering with the panel and step back.","You're at a panel in the tree.",1),
       Scene(55,{'EAST':53,'TALK':56},"You're in a great big hall full of Tree Elves scurrying around. Most of them are drinking coffee but you smell rum in the air too, as well as caramel. It smells like someone rubbed vanilla bean lotion on a pirate at a coffeehouse basically. The elves are chatting and having a good time and making wooden swords and scribbling on pads of parchment all over the place.","You're in the Tree Elves' Great Hall.",0),
       Scene(56,{'BACK':55},"You're at a table talking to one of the drunken Tree Elves.","You're at one of the elves' tables.",1),
       Scene(57,{'SOUTH':47,'NORTH':58},"You're on 6th and Main streets. The road is crumbling to pieces and hasn't been fixed in years. A few rusted old cars line the street inside the concrete barriers blocking travel through this stretch of road. A small gap in the barrier allows travel north to 7th and Main, and the rickety old train station gates are a stones throw to the south.","You're on 6th and Main streets.",0),
       Scene(58,{'SOUTH':57,'NORTH':59},"You're on the corner of 7th and Main. The road south is blocked off by barricades and leads to the crumbly and deteriorated intersection of 6th and Main. The road here isn't as bad but the traffic signal has some broken lights and there are some seedy looking individuals lurking about. To the north is the busier 8th and Main intersection, and to the east and west lie more of 8th street and abandoned shops.","You're on 7th and Main streets.",0),
       Scene(59,{'SOUTH':58,'WEST':60,'EAST':63},"You're on 8th and Main where the traffic is busy and people walk all around the sidewalks. Various ethnic shops are open up and down 8th street to the east and west and Main leads north and south to 9th and 7th streets, respectively.","You're on 8th and Main streets.",0),
       Scene(60,{'EAST':59,'NORTH':61},"You're on West 8th street. Busy people hustle and bustle up and down the street and ethnic food shops line the street. To the north is a shop called 'La Casa de La Mesa'. The road to the west seems uninteresting, but Main street is to the east.","You're on West 8th street.",0),
       Scene(61,{'SOUTH':60,'ORDER':62},"You're inside La Casa de la una Mesa, which translates to 'The House of the One Table'. It's a Mexican food shop selling bootlegged cola made with cane sugar as well as various exotic and not-approved-by-government-standards coffee and chocolate products. The shop is also a coffee house, but only has a single table. No one sits at the table; everyone simply leans up against the wall sipping drinks and chatting. The door to the south exits to 8th street.","You're inside La Casa de la Una Mesa.",0),
       Scene(62,{'BACK':61},"You finish your order and go lean up against a wall.","You're leaning against a wall at La Casa de la Una Mesa.",1),
       Scene(63,{'WEST':59},"You're on East 8th street. The road is squashed into one lane by swarms of people and carts as an impromptu farmers' market commences. Various carts sell various things peddling to individuals as well as business owners at the nearby restaurants and shops. Shops line the street to the north and south and Main street is to the west.","You're on East 8th street at the market.",0),
       Scene(64,{},"","",0),
       Scene(65,{},"","",0),
       Scene(66,{},"","",0),
       Scene(67,{},"","",0),
       Scene(68,{},"","",0),
       Scene(69,{},"","",0),
       Scene(70,{},"","",0),
       Scene(71,{},"","",0),
       Scene(72,{},"","",0),
       Scene(73,{},"","",0),
       Scene(74,{},"","",0),
       Scene(75,{},"","",0)]

# Initializing the Game
gameover = 0
CurScene = map[CurSceneNum]

# Abbreviations for Various Commands
abbr = {'N':'NORTH','E':'EAST','W':'WEST','S':'SOUTH',
'U':'UP', 'D':'DOWN','B':'BACK','L':'LOOK',
'H':'HELP','X':'EXIT','?':'HELP','$':'SAVE',
'R':'RECIPES','I':'INVENTORY','M':'MIX','#':'MAP',
'T':'TALK','O':'ORDER'}

# Toastable Items
toastitems = {'ICE':'WATER','MILK':'EVAPORATED MILK'}

# Menus For Purchasing Things In Game
# menus list > individual menus dictionaries > key/letter choice and item attribute list > price, amount, item name
menus = [[[8,1,'COFFEE'],[3,1,'ICE'],[6,1,'BEAN'],[15,3,'BEAN']],
[[10,1,'MILK'],[15,1,'CREAM']],
[[4,1,'WATER'],[9,3,'WATER'],[12,1,'CANDY']],
[[6,1,'COCOA MIX'],[30,6,'COCOA MIX'],[14,1,'ESPRESSO'],[50,5,'CANDY']],
[[5,1,'COFFEE']],
[[50,1,'RAIL MAP'],[20,1,'CART RENTAL'],[15,1,'BERRY SYRUP'],[13,1,'ESPRESSO']],
[[10,1,'BEAN'],[15,5,'DARK CHOCOLATE']],
[[20,1,'COFFEE JELLO SHOT'],[35,1,'CAPPUCCINO CON CARNE'],[50,1,'FRENCH ROAST RODEO'],[100,1,'FOUR-LEGGED MOUNTAIN SNAKE']]]

# Random phrases for certain areas and the list of streets for each town
streetphrases = ["A group of hippie type people walks through the street.","Kids on the sidewalk play around near trees and mailboxes.","A couple holding hands walks slowly down the street with coffee.","Skateboarders do tricks through the street.","A lone well-dressed businessman walks down the street with his coffee, constantly checking his watch."]
town_a_streets = [2,4,5,9,12,15,17,30,39]
town_b_streets = [47,57,58,59,60,63]

################################################################################################
clearscreen()

#Start Curses Screen
ts = Popup(79,23)
ts.show()
# Title Screen Text
ts.scr.addstr(1,2,"COFFEE ADVENTURE v" + version)
ts.scr.addstr(2,2,"By David Millar")
ts.scr.addstr(4,2,"An interactive fiction game about:")
ts.scr.addstr(5,4,"Being a Barista, Mixing Drinks, Exploring the World, and Other Nonsense.")
ts.scr.addstr(6,2,"You might think you're an ordinary person, but you're actually...")
ts.scr.addstr(7,4,"A COFFEE WARRIOR!")
ts.hr(9)
ts.scr.addstr(11,2,"Name:")
ts.scr.addstr(12,2,"Pass:")
ts.scr.addstr(14,2,"New Users: Create login credentials.")
ts.scr.addstr(15,2,"Returning Users: Enter your login credentials.")
ts.scr.addstr(17,2,"Warning: All passwords are stored as plaintext!",curses.A_STANDOUT)
ts.hr(19)
ts.scr.addstr(21,2,"davmillar@gmail.com")
ts.scr.addstr(21,63,"thegriddle.net")
ts.scr.refresh()

# Ask for logins until it returns true
# Either correct password, new user, or old save file with new password
login = False
savedir = os.path.expanduser("~/.coffeesave/")
if os.path.exists(savedir) == False:
    os.mkdir(savedir)
while login == False:
    curses.echo()
    ts.scr.addstr(11,9," "*30,curses.A_UNDERLINE)
    ts.scr.addstr(12,9," "*30,curses.A_UNDERLINE)
    playername = ts.scr.getstr(11,9,30)
    temppwd = ts.scr.getstr(12,9,30)
    if playername != "":
        sf = savedir + ((to_upper(playername) + ".DAT").replace(" ","_"))
        if os.path.exists(sf):
            login = loadgame(sf,temppwd)
        else:
            cdata['pwd'] = [temppwd]
            login = True
    else:
        login = False

ts.close()

if cdata.has_key('exotic') == False:
    cdata['exotic'] = [0,'']

#Save Game Once
savegame(sf)

print "You wake up from a hangover in the bathroom of a funky movie theatre. You've got your trusty blender and a few other things, but other than that it's just you and your wits. Time to get back home to your apartment!"

# Main Loop for the Game
while gameover == 0:
    # Room Desc
    CurScene.print_info()
    # Input
    command = get_input(1)
    NewNum = choice(CurScene, command)
    if NewNum == -1:
        gameover = 1
        print "\nWant to save before closing? (Y/N)"
        yn = get_input(1)
        if yn.find("Y") != -1:
            savegame(sf)
        clearscreen()
    elif NewNum != CurSceneNum:
        CurSceneNum = NewNum
        CurScene = map[CurSceneNum]
        # Random Encounters and Such
        r = random.randint(1,50)
        ishere = 0
        if event[8] == 2 and itemnum("NUTTY COFFEE") > 0:
            print "\nAn odd little squirrel with braces follows you."
        elif 1 <= r <= 4 and CurSceneNum in town_a_streets:
            print "\n" + streetphrases[r-1]
            streetphrases.append(streetphrases[r-1])
            del streetphrases[r-1]
        elif r == 5 and event[4] == 1:
            print "\nTJG bounces into the area, causing mayhem and misfortune and destructively taking bites out of trees, rather than constructively taking a bite out of crime."
        elif r in [6,7] and cdata['exotic'][0] > 0:
            found = random.randint(1,min(10,cdata['exotic'][0]))
            cdata['exotic'][0] -= found
            choins += found
            print "\nYou alertness from drinking that",cdata['exotic'][1],"has made you more aware of your surrounds and you have found",found,"choins on the ground!"
            if cdata['exotic'][0] == 0:
                print "...but now you've lost your buzz from the caffiene..."
        elif r == 50 and (CurSceneNum in town_a_streets or CurSceneNum in town_b_streets) and cdata['exotic'][0] < 1 and choins <= 150 and event[0] > 0:
            ishere = 1
            print "\nThe exotic coffee cart is here! Type EXOTIC to try a product!"

# Idea: Unlocks Water Filter allowing free water from fountains, etc
# Puzzle: Hedge Maze of some sort - make it good
# Puzzle: Map through toaster oven yields invisible ink message
# Puzzle: An encoded PROTIP message that you have to solve and have a professor verify in order to unlock a recipe
# Todo: Get CB radio for trucker ---> unlock truck ride to east city!!
# Idea: On-Server Person to Person Trading
# Idea: Can initiate trade with someone only trading specific items
# Idea: Have a random selection of 3 or 4 coffees out of 10 per game, trade to get others
# Idea: 20% or so chance that trade will get "mixed up" and you'll get a special coffee
