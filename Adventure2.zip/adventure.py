#! /usr/bin/env python

# Created by David Millar
# Project Created August 4, 2007
# Last Modified January 19, 2008
# Version .102

import random, os, os.path, pickle, readline, curses, time

from data import data
from world import world
from sys import stderr
from events import random_encounter

import scene, staticcode, mapping, drinks, events, shop

from staticcode import *
from mapping import *
from drinks import *
from scene import *
from shop import *

# Load the Game from a Save File
def loadgame(fname,temppwd):
    # Open filename specified
    infile = open(fname,"r")
    loader = pickle.load(infile)
    infile.close()
    
    # Check password
    if temppwd != loader.password:
        return False
    
    # Password Test Successful, Disperse Data
    global data
    data = loader
    shop.data = scene.data = events.data = data
    staticcode.data = mapping.data = drinks.data = data
    
    # Check proper events length
    while len(data.event) < 9:
        data.event.append(0)
    
    # Reapply map changes and sky changes rather than loading the entire map
    tempchanges = data.map_changes
    data.map_changes = []
    for c in tempchanges:
        if c[0] == 1:
            map[c[1]].add_opt(c[2],c[3])
        elif c[0] == 2:
            map[c[1]].rem_opt(c[2])
        elif c[0] == 3:
            map[c[1]].no_code()
        elif c[0] == 4:
            if len(c) < 4:
                c.append(0)
            map[c[1]].set_desc(c[2],c[3])
    
    # Login successful
    return True

# Save the Game to a Save File
def savegame(fname):
    infile = open(fname,"w")
    pickle.dump(data,infile)
    infile.close()

# Choosing an Option from the Scene
def choice(Cs, Opt):
    # Split string into list of words
    phr = Opt.strip().split(" ")
    
    # Check if case-sensitive data needed
    if (to_upper(phr[0]) in ["NEWPASS"]) == False:
        phr = to_upper(Opt.strip()).split(" ")
    
    # Get rid of "GO" if used - ie "GO EAST"
    if phr[0] == "GO":
        if len(phr) == 1:
            return Cs.num
        del phr[0]
        
        
    # Substitute Abbreviations for Full Text
    if phr[0] in abbr.keys():
        phr[0] = abbr[phr[0]]
    
    # Commands----------------------------------------------------------------------
    # Mix a drink or item
    if phr[0] == "MIX":
        if len(phr) > 1:
            if phr[1].isdigit() and phr[2]:
                for i in range(int(phr[1])):
                    mix_drink(" ".join(phr[2:]))
            else: 
                mix_drink(" ".join(phr[1:]))
        else:
            mix_drink("")
    # Show the recipe book
    elif phr[0] == "RECIPES":
        if len(phr) > 1:
            recipebook(" ".join(phr[1:]))
        else:
            recipebook("")
    # Create a new password
    elif to_upper(phr[0]) == "NEWPASS":
        if len(" ".join(phr[1:])) > 30:
            print "\nNew password too long - sorry."
        else:
            if len(phr) == 1:
                print "\nPlease choose a new password."
                new_pw = get_input(0)
            else:
                new_pw = " ".join(phr[1:])
            print "\nType it again to confirm."
            tmppass = get_input(0)
            if tmppass == new_pw:
                data.password = new_pw
                print "\nNew password and game saved."
                savegame(data.save_file)
            else:
                print "\nPasswords don't match - sorry."
            
    # Use a payphone is one is present
    elif Cs.num in world.payphones and phr[0] in ["PHONE","PAYPHONE"]:
        if len(phr) > 1:
            for i in range(int(phr[1])):
                phonecall(" ".join(phr[1:]))
        else:
            phonecall("")
    # Display a map
    elif phr[0] == "MAP":
        if len(phr) > 1:
            show_map(" ".join(phr[1:]))
        else:
            show_map('none')
    # Look at the long description of the room
    elif phr[0] in ["LOOK","EXAMINE"]:
        map[Cs.num].visit = 0
    # Save the game
    elif phr[0] == "SAVE":
        savegame(data.save_file)
        print "\nFile saved (hopefully successfully)."
    # Clear the save file
    elif phr[0] == "CLEARSAVE":
        os.remove(data.save_file)
        print "\nSave file cleared from server or local directory."
    # Quit the game
    elif phr[0] == "EXIT":
        print "\nAre you sure you want to exit? (Y/N)"
        y_n = get_input(1)
        if y_n[0] == "Y":
            return -1
    # Give the player help
    elif phr[0] == "HELP":
        print "\nEach scene comtains a list of possible commands for that location, but other universal commands exist, and some commands have shortcuts to make them easier to use."
        print "Additional Commands and Shortcuts:"
        abbrs = abbr.keys()
        abbrs.sort()
        for ab in abbrs:
            print ab, "|", abbr[ab]
    # Show the credits of the game
    elif phr[0] in ["ABOUT","VERSION","CREDITS"]:
        credits()
    # Show the player's inventory
    elif phr[0] == "INVENTORY":
        show_inv()
    # Move to another room and do the action associated with it
    elif Cs.opts.has_key(phr[0]):
        newnum = Cs.opts[phr[0]]
        ns = map[newnum]
        ns.action()
        return newnum
    # Visit the exotic coffee stand
    elif phr[0] == "EXOTIC":
        if data.ishere == 1:
            go_shop(7,"Oh me! Oh my! That scent!|Can it be? What luck you have!|It's the magical exotic coffee cart!")
        else: 
            print "\nSorry, but the exotic coffee cart isn't here anymore."
    # Return an appropriate response for an inappropriate command
    else:
        if phr[0] in ['NORTH','UP','DOWN','EAST','WEST','SOUTH']:
            print "\nI don't believe it's possible to go",phr[0],"from here."
        elif phr[0] == "ORDER":
            print "\nThere's nothing to order here."
        elif phr[0] == "USE":
            if "MAP" in phr:
                print "\nTo use a map, just type 'MAP <name of map>'. You don't need the word 'USE'."
            else:
                print "\nYou don't need to use an item - it will use itself when the moment is right."
        elif 1:
            print "\nI don't understand that."
    return Cs.num

# Make a Call to an NPC
def phonecall(who):
    if who == "":
        print "\nWho would you like to call?"
        who = get_input(1)
    if who in ["ARMONDO","CANDY","STRIPPER","GANGSTER","MEXICAN","MEXICAN GUY","LATINO"]:
        if data.event[8] == 4 and data.book.has_key('PSYCH WARD') == 0:
            print "\nYou call up Candy and Armondo and say hello. 'Hey papi!' Candy says. 'What you need?' You explain that you're looking for a recipe for a love potion. 'Well, I know a coffee drink that makes people CRAZY like they in love. It's called a PSYCH WARD. You need a BLOODY LARRY and a NUTTY COFFEE to make it. You got that written down? OK, me and Armondo are going to East Side City to meet a trick - er - a friend at a motel. Call us if you need anything!' She hangs up."
            add_recipe('PSYCH WARD','NUTTY COFFEE','BLOODY LARRY',3)
        else:
            print "\nYou call up Candy and Armondo, and Armondo answers. You hear weird grunting sounds and Armondo says 'Hey bro, I'm kinda busy. Want to call back later?' He hangs up."
    elif who in ["FLO","TRUCK STOP"]:
        if data.book.has_key("SHELLY GROUNDS") and len(world.menus[4]) == 1:
            print "\nYou call Flo at the truck stop. 'Hey there ",data.player_name+", what do ya need?' 'I need to make some smoother coffee. Can you save me some egg shells for the recipe?' 'Sure hun, just remind me every once in a while by giving me a call and I'll save them here for you. All I'll charge ya is 5 choins for washing them out. Take care!' She hangs up."
            world.menus[4].append([5,5,'EGG SHELLS'])
        else:
            print "\nYou call Flo at the truck stop, but the phone keeps ringing. She must be really busy right now. Try back later."
    elif who.find("GIRLFRIEND") != -1:
        print "\nYou call your ex-girlfriend's cell phone and she picks up and greets you with an overly cheerful hello. 'Guess what I did!' she exclaims! You sense something bad coming on. 'Remember when we were to gether and you told me I should kill my parents? Well, I tried to poison them, and now I'm in the mental ward. Just thought I would let you know!' She hangs up on you."
    else:
        print "\nYou dial a number but it ends up being some jerk you don't know."

# Use Toaster Oven - Returns 0 if user cancels
def toast():
    # Get item to toast
    print "\nWhat item would you like to put in the toaster oven? (X to stop)"
    item = get_input(1)
    if item in ['X','NONE']:
        return 0
    if itemnum(item) == 0:
        print "\nYou don't have that item to toast."
    # Choose the amount
    print "\nHow many %s do you want to toast?" % (item)
    amt = get_input(2)
    if amt <= 0:
        return 1
    # Check if item is toastable and modify it
    if item in toastitems.keys():
        newitem = toastitems[item]
    elif item[0:5] == "ICED ":
        newitem = item[5:]
    else:
        print "\nYou're about to toast the item, but you realize it's not a very good idea."
        return 1
    amt = max(amt, data.inventory[item])
    rem_item(item,amt)
    add_item(newitem,amt)
    print "\nYou put the",item,"in the toaster oven and a few minutes later you have",newitem+"."
    return 1

# Sell things to an NPC
def sellthings():
    sellitem = ""
    while sellitem != "X" and data.choins < 100:
        sellitem = get_input(1)
        if sellitem == "X":
            break
        amt = itemnum(sellitem)
        sellable = ['MILK','COCOA MIX','BEAN','WATER','RAIL MAP','BERRY SYRUP','CARAMEL SYRUP','CINNAMON SYRUP','SUGAR','CANDY']
        if amt == 0:
            print "\n'You don't have that to sell to me guy. Try something else."
        elif sellitem in ["ARMONDO'S NOTE","MAIN MAP","TREE MAP"]:
            print "\n'I don't have any use for that item. You hold onto it.'"
        elif sellitem == "BRAZILIAN CARWASH":
            if itemnum("BRAZILIAN CARWASH") > 0:
                print "\n'Wow! A BRAZILIAN CARWASH! They don't make those anymore! Hold onto those kid!'"
            else:
                print "\n'Hah! Nice try! You're bluffing. I haven't seen a BRAZILIAN CARWASH in years!'"
        elif data.book.has_key(sellitem) or sellitem in sellable:
            if sellitem in sellable:
                lv = .7
            else:
                lv = data.book[sellitem][0]
            max = int(5 * lv)
            min = -max
            price = int((3 ** (lv + 1)) + (random.randint(min,max)))
            print "'I can pay you %d each for those. You have %s of those. How many do you want to sell me?" % (price, amt)
            sellamt = get_input(2)
            data.choins += (sellamt * price)
            rem_item(sellitem,sellamt)
            print "'Alright, you just sold me %d %s for %d choins.' Anything else?" % (sellamt, sellitem, sellamt*price)
        else:
            print "\n'I don't have any use for that item. You hold onto it.'"
    if data.choins >= 100:
        print "\n'Sorry, I don't buy from rich yuppies like you who have money overflowing their pockets.'"

# Initializing the Game
gameover = 0
CurScene = map[data.CurSceneNum]

# Abbreviations for Various Commands
abbr = {'N':'NORTH','E':'EAST','W':'WEST','S':'SOUTH',
'U':'UP', 'D':'DOWN','B':'BACK','L':'LOOK',
'H':'HELP','X':'EXIT','?':'HELP','$':'SAVE',
'R':'RECIPES','I':'INVENTORY','M':'MIX','#':'MAP',
'T':'TALK','O':'ORDER'}

# Toastable Items
toastitems = {'ICE':'WATER','MILK':'EVAPORATED MILK'}

################################################################################################
clearscreen()

try:
    #Start Curses Screen
    ts = Popup(79,23)
    ts.show()
    # Title Screen Text
    ts.scr.addstr(1,2,"COFFEE ADVENTURE v" + data.version)
    ts.scr.addstr(2,2,"By David Millar")
    ts.scr.addstr(4,2,"An interactive fiction game about:")
    ts.scr.addstr(5,4,"Being a Barista, Mixing Drinks, Exploring the World, and Other Nonsense.")
    ts.scr.addstr(6,2,"You might think you're an ordinary person, but you're actually...")
    ts.scr.addstr(7,4,"A COFFEE WARRIOR!")
    ts.hr(9)
    ts.scr.addstr(11,2,"Name:")
    ts.scr.addstr(12,2,"Pass:")
    ts.scr.addstr(14,2,"New Users: Create login credentials.")
    ts.scr.addstr(15,2,"Returning Users: Enter your login credentials.")
    ts.scr.addstr(17,2,"Warning: All passwords are stored as plaintext!",curses.A_STANDOUT)
    ts.hr(19)
    ts.scr.addstr(21,2,"davmillar@gmail.com")
    ts.scr.addstr(21,63,"thegriddle.net")
    ts.scr.refresh()
    
    # Ask for logins until it returns true
    # Either correct password, new user, or old save file with new password
    login = False
    savedir = os.path.expanduser("~/.coffeesave/")
    if os.path.exists(savedir) == False:
        os.mkdir(savedir)
    while login == False:
        curses.echo()
        ts.scr.addstr(11,9," "*30,curses.A_UNDERLINE)
        ts.scr.addstr(12,9," "*30,curses.A_UNDERLINE)
        data.player_name = ts.scr.getstr(11,9,30)
        temppwd = ts.scr.getstr(12,9,30)
        if data.player_name != "":
            data.save_file = savedir + ((to_lower(data.player_name) + ".cof").replace(" ","_"))
            if os.path.exists(data.save_file):
                login = loadgame(data.save_file,temppwd)
                if login == False:
                    ts.scr.addstr(14,2,"The password you have entered is incorrect.")
                    ts.scr.addstr(15,2,"Please try again or create a new account instead.")
            else:
                data.password = temppwd
                login = True
        else:
            login = False
finally:
    ts.close()

#Save Game Once
savegame(data.save_file)

print "You wake up from a hangover in the bathroom of a funky movie theatre. You've got your trusty blender and a few other things, but other than that it's just you and your wits. Time to get back home to your apartment!"

# Main Loop for the Game
while gameover == 0:
    # Room Desc
    CurScene.print_info()
    
    # Input
    command = get_input(0)
    NewNum = choice(CurScene, command)
    if NewNum == -1:
        gameover = 1
        print ""
    elif NewNum != data.CurSceneNum:
        data.CurSceneNum = NewNum
        CurScene = map[data.CurSceneNum]
        # Check if squirrel following you, otherwise initiate a random encounter
        if data.event[8] == 2 and itemnum("NUTTY COFFEE") > 0:
            print "\nAn odd little squirrel with braces follows you."
        else:
            random_encounter()