# Created by David Millar
# Last Modified January 23, 2008

import random, os, os.path, pickle, readline, curses, time

from data import data
from world import world

from new import instancemethod

from staticcode import *
from mapping import *
from drinks import *
from shop import *

def no_action(self):
    pass

# Scene Class - A scene is usually a room but can also be an event.
class Scene:
    # Initiation Function
    def __init__(self, num, opts, desc, short, action = no_action):
        self.num = num
        self.description = desc
        self.revisit = short
        self.opts = opts
        self.action = instancemethod(action, self, Scene)
        self.visit = 0
    # Display Scene and Options
    def print_info(self):
        if self.visit == 0:
            print "\n" + self.description.replace('$name',data.player_name)
            self.visit = 1
        else:
            print "\n" + self.revisit.replace('$name',data.player_name)
        print "Choices:",
        for dir in self.opts.keys():
            print dir,
        if self.num in world.payphones and itemnum("PHONE CARD") > 0:
            print "PAYPHONE",
        print "(HELP for more)"
    # Add or Remove an Option
    def add_opt(self, name, n):
        self.opts[name] = n
        data.map_changes.append([1,self.num,name,n])
    def rem_opt(self, name):
        del self.opts[name]
        data.map_changes.append([2,self.num,name])
    # Change extra code status or description of scene
    def no_code(self):
        self.action = instancemethod(no_action, self, Scene)
        data.map_changes.append([3,self.num])
    def set_desc(self, text, short=0):
        if short == 0:
            self.description = text
        else:
            self.revisit = text
        data.map_changes.append([4,self.num,text,short])

# The Map of the Game
map = []

# Town 1 Theatre - Bathroom
index = 0
exits = {'NORTH':1}
description = "You are in a friggen bathroom at the movie theatre. It smells like nasty, evil stuff in here. It's so, so, so gross. Worst hell hole you ever saw. You get the sudden urge to go north and east to the outside and gamble."
revisit_desc = "You're at the movie theatre bathroom."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Theatre - Lobby
index = 1
exits = {'SOUTH':0,'EAST':2}
description = "You are in the lobby of the nasty movie theatre. The stench from the mens' room invades the air rendering the smells of popcorn and snacks from the snack bar useless."
revisit_desc = "You're at the movie theatre."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Main @ Theatre
index = 2
exits = {'WEST':1,'TALK':3}
description = "You are just outside a nasty looking movie theatre. Shady characters lurk nearby. The characters happen to be three Latin gang member types who have set up a typical shell game. The cigar smoking boss of the operation has the typical machismo image There's a big group of people walking around the street in the north."
revisit_desc = "You're outside the movie theatre near thugs."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Main @ Theatre - Convo
index = 3
exits = {'BACK':2}
description = "Macho Man says 'Alright, hand over 10 choins.' 'Choins?' you ask. 'Yeah, choins. The H is invisible like how in some words letters are silent. Didn't you go to public school?' You hand over the choins and he places a bean under one of three cups. After some sliding around with the cups, you successfully fail at correctly picking the right cup. 'Here kid,' the guy says as he hands you the bean. 'Consolation prize.' The crowd in the street to the north has started thinning out and one of the gangsters off to the side chuckles and says 'Go back to the library where you belong, fool!'"
revisit_desc = "Scram, kid!"
def this_action_03(self):
    if data.event[1] == 0:
        add_item("BEAN",1)
        data.choins -= 10
        map[2].add_opt("NORTH",4)
        map[2].set_desc("You are just outside a nasty looking movie theatre. Shady Latin gang members have a shell game set up nearby, and from previous experiences you know to avoid gambling like the plague.")
        data.event[1] = 1
    elif data.event[1] == 1:
        map[3].set_desc("You walk up to the gangsters and the boss guy says 'Get lost, fool!'")
        data.event[1] = 2
    elif data.event[1] == 3:
        map[3].set_desc("You walk up to the gangsters but they tell you to get lost.")
        if (data.inventory.has_key("ARMONDO'S NOTE") == 0):
            print "\nYou walk up to the gangsters and flash a picture of Candy in front of them. 'Woah, is that Candy?' the boss guy asks. I ain't seen her since high school!' He scribbles something on the back of a receipt for frozen wonton burrito meals, and you do the math and realize that he wants you to give candy the number."
            add_item("ARMONDO'S NOTE",1)
    elif data.event[1] == 4:
        print "\nYou see Candy with Armondo, and they wave you over. 'Hey, thanks for hooking us up again! And sorry Armondo took your choins in his little game, teehee!' She hands you 5 choins. 'Uhh, he took 10 choins from me, not fi-' 'SHUT UP RUBE!' Candy laughs at Armondo and kisses him on the cheek. 'We're going to the back seat of Armondo's car for coffee. See ya! They walk away and get into Armondo's car, which starts bucking around a bit. Then it suddenly starts up and leaves, opening the street to the south. As they leave you see a guy walk into the theatre with his arms full of various snack bar supplies."
        data.choins += 5
        map[2].rem_opt("TALK")
        map[2].add_opt("SOUTH",15)
        map[1].add_opt("ORDER",16)
this_scene = Scene(index,exits,description,revisit_desc,this_action_03)
map.append(this_scene)

# Town 1 Main @ Crossroad
index = 4
exits = {'NORTH':5, 'SOUTH':2, 'EAST':12, 'WEST':17}
description = "You're on a street downtown. Everything is kinda dirty and creepy around here. Graffiti covers just about everything. A badly defaced sign points north and says 'Public Library Ahead'."
revisit_desc = "You're at a dirty, creepy street downtown."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Main @ Stores
index = 5
exits = {'SOUTH':4, 'EAST':6, 'NORTH':9}
description = "You're on a dirty street downtown. The public library is on the east side of the street. Hustling and bustling people go in and out of various buildings, mostly shops, while others walk up and down the street."
revisit_scene = "You're downtown near shops and the library."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Library
index = 6
exits = {'WEST':5}
description = "You're inside the public library. Notices all over warn that the library will be closing shortly for a long-term renovation plan and explain some mumbo jumbo about inter library loans. In the short amount of time you have, you copy down some coffee recipes from a book in the nonfiction section. On the way out you grab one of the free maps they had. You use a Sharpie to write MAIN in big bold letters on the map."
revisit_desc = "You're at the library which is under renovation."
def this_action_06(self):
    map[5].rem_opt("EAST")
    add_item('MAIN MAP',1)
    add_recipe('ICED COFFEE','COFFEE','ICE',1)
    add_recipe('ESPRESSO','COFFEE','BEAN',2)
    add_recipe('CAPPUCCINO','ESPRESSO','MILK',2)
    add_recipe('CREAMY COFFEE','COFFEE','MILK',1)
this_scene = Scene(index,exits,description,revisit_desc,this_action_06)
map.append(this_scene)
    
# Town 1 Coffeeshop 1 (Oldish)
index = 7
exits = {'EAST':5, 'ORDER':8}
description = "You're in a trendy but old looking coffee shop. It's not the kind of coffee shop that posers would know about - only the social outcasts and those in the 'know' would find it. The old-school wooden bar is rough but polished. Behind the bar sits shelves of various flavored syrups and powders for coffee drinks. A couple people sit alone at small tables with their laptops while a few groups of people sit together and chat at wall or corner tables."
revisit_desc = "You're in an old coffee shop downtown."
def this_action_07(self):
    if data.event[1] >= 3 and (data.book.has_key("SYRUP") == 0):
        print "\n'Hey, I see you have some candy. Did you know you can mix it with water to make various sugary syrups for your drinks?'"
        add_recipe('SYRUP','CANDY','WATER',1)
this_scene = Scene(index,exits,description,revisit_desc,this_action_07)
map.append(this_scene)

# Town 1 Coffeeshop 1 (Oldish) - Order
index = 8
exits = {'BACK':7}
description = "You finish up your order and get ready to be on your way."
revisit_desc = "You're at the counter in a shop."
def this_action_08(self):
    go_shop(0)
this_scene = Scene(index,exits,description,revisit_desc,this_action_08)
map.append(this_scene)

# Town 1 Main @ Suburbs
index = 9
exits = {'SOUTH':5, 'EAST':10}
description = "You're on a street near the edge of the downtown area. Shops are starting to thin out into a typical neighborhood where people live. An electric fence guards a set of train tracks are along the north edge."
revisit_desc = "You're at the edge of town."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Farm
index = 10
exits = {'WEST':9,'TALK':11}
description = "You're in the backyard of a home in the middle of the city. A farmer type guy is half asleep and his wife is standing near him over by the fence. Cows graze in the patchy yard."
revisit_desc = "You're at a farm-like house."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Farm - Wife
index = 11
exits = {'BACK':10}
description = "The farmer's wife stands around impatiently. Impatiently and angrily."
revisit_desc = "You're standing in front of the farmer's wife."
def this_action_11(self):
    if data.event[0] == 0:
        print "\nYou ask the farmer's wife what's going on, and she explains that her husband is severely exhausted. 'I would let him just get his sleep, but I'm a cruel woman and these cows need to be tended to. Can you get my husband something strong to drink so he can start selling milk again? If you need supplies, try the coffee shop in town.'"
        data.event[0] = 1
        map[5].add_opt("WEST",7)
    elif data.event[0] == 1:
        if data.inventory.has_key("ESPRESSO"):
            print "\n'Ah, that ESPRESSO will do the trick!' The wife promptly takes the high powered shot of coffee and jams it down Farmer Brown's throat. He wakes up INSTANTLY. 'Thanks for waking up my good for nothing husband. Here's some milk for your trouble. Come back soon and buy some more if you like it!'"
            map[11].set_desc("The farmer's wife stands around impatiently. Impatiently and angrily. But she has product to sell, so you ought to buy some.")
            add_item("MILK",3)
            rem_item("ESPRESSO",1)
            data.event[0] = 2
        else:
            print "\n'I don't think you have anything strong enough, kiddo. Come back with something high powered, like something that begins with E and ends with SPRESSO.'"
    elif 1:
      go_shop(1)
this_scene = Scene(index,exits,description,revisit_desc,this_action_11)
map.append(this_scene)

# Town 1 Red Light District
index = 12
exits = {'WEST':4,'NORTH':13,'SOUTH':27}
description = "You're downtown in the red light district. The red light has stopped traffic, but you're on foot, so you can visit plenty of the fine local establishments."
revisit_scene = "You're in the red light district."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Strip Club
index = 13
exits = {'SOUTH':12, 'TALK':14}
description = "You're in a strip club. It's not very lively - it's probably the wrong time of day for serious stripping to go on. One of the strippers is sitting at a booth drinking something."
revisit_scene = "You're in the strip club."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Strip Club - Candy
index = 14
exits = {'BACK':13}
description = "'Hey, my name is Candy. Here, have a piece of candy. I Like shaking my stuff and giving out candy. But I really wish I could find a sweet guy so I can stop stripping. Let me know if you find a decent guy. I don't want a thug or a gangster or anything..."
revisit_scene = "You're standing in front of Candy."
def this_action_14(self):
    if data.event[1] <= 1:
        data.event[1] = 3
        add_item("CANDY",1)
    elif data.event[1] == 3:
        if itemnum("ARMONDO'S NOTE") == 1:
            print "\n'Armondo? NO WAY! I remember how cute he was back in the day! I'm definitely gonna go see him! Thanks, and have some more candy!' She runs out and never looks back."
            pieces = random.randint(5,7)
            add_item("CANDY",pieces)
            data.event[1] = 4
            map[14].set_desc("There's no one here to talk to. Candy has gone off with Armondo somewhere.")
            map[14].set_desc("There's no one here.",1)
            map[13].rem_opt("TALK")
        else:
            map[14].set_desc("'You gonna find a guy for me honey?' Candy asks. You see the look of desperation in her eyes and decide to leave.")
this_scene = Scene(index,exits,description,revisit_desc,this_action_14)
map.append(this_scene)

# Town 1 Main @ Apartments
index = 15
exits = {'NORTH':2,'EAST':21}
description = "You're in the south part of downtown. It's starting to fade from the ghetto to the preppy rich kid part. You shudder involuntarily because your ex-girlfriend's apartment is on the east side of the street."
revisit_desc = "You're outside the apartment building."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Theatre - Lobby Snack Bar
index = 16
exits = {'BACK':1}
description = "You're at the snack bar of the movie theatre. Overpriced crap!!! Run!"
revisit_desc = "You're at the theatre snack bar."
def this_action_16(self):
    go_shop(2)
this_scene = Scene(index,exits,description,revisit_desc,this_action_16)
map.append(this_scene)

# Town 1 Town Square
index = 17
exits = {'EAST':4,'NORTH':18,'WEST':23}
description = "You're in the town square downtown and there's a giant fountain in the middle. Unusual looking shops, some of which are closed for the weekend or don't open for a while, line the square and benches and trees and flowers adorn the area."
revisit_desc = "You're at the town square."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Coffeshop 2 (modern)
index = 18
exits = {'SOUTH':17, 'TALK':19}
description = "You walk into a little coffee shop, quite like the millions of others around town. Unlike the others, a friend of yours works here. He's waiting on a few customers but probably has time to talk."
revisit_desc = "You're in a friend's coffee shop."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Coffeeshop 2 (modern) - Talk
index = 19
exits = {'BACK':18}
description = "Looks like Jared is counting on you..."
revisit_desc = "You're in front of your friend Jared."
def this_action_19(self):
    if data.event[2] == 0:
        print "\nDude, you have no idea what just happened. This dude ordered an iced venti americano and freaking THREW IT OVER THE COUNTER WHEN HE DIDN'T LIKE IT. You HAVE to help me get even dude. Can you help me? Unfortunately, I can't comp a lot of supplies, so here's 20 choins - all I got - I need you to make three ICED AMERICANOs and bring them back. Here's how to make one..."
        add_recipe("AMERICANO","ESPRESSO","WATER",2)
        add_recipe("ICED AMERICANO","AMERICANO","ICE",2)
        data.event[2] = 1
        data.choins += 20
    elif data.event[2] == 1 and itemnum("ICED AMERICANO") >= 3:
        print "\n'Alright dude, now you need to go outside and look for a guy that looks like a fricken loser. You know the type - preppy clothes, talking on his cellphone... I'm counting on you! If this goes well, the CS forums will rejoice!'"
        data.event[2] = 2
        d = random.choice([4,5,9,12,15])
        map[d].set_desc(map[d].description + " The jerk from the coffee shop is here.")
        map[d].set_desc(map[d].descriptionshort + " The jerk from the coffee shop is here.",1)
        map[d].add_opt('TALK',20)
        map[20].add_opt('BACK',d)
    elif data.event[2] >= 3:
        print "\n'Thanks dude! That was awesome! Here - have a MOCHA on me! Glad to hear that guy got what he deserved! Go forth and spread coffee to the world my brotha!'"
        add_item("MOCHA",1)
        map[19].no_code()
this_scene = Scene(index,exits,description,revisit_desc,this_action_19)
map.append(this_scene)

# Town 1 Jerk - Random Location
index = 20
exits = {}
description = "The guy's body writhes in pain at the electrocution. Best not stick around..."
revisit_desc = "You're in front of an electrocuted jerk."
def this_action_20(self):
    if data.event[2] == 2:
        rem_item("ICED AMERICANO",3)
        data.event[2] = 3
        print "\nYou walk up to the jerk and say 'Hey, I heard you threw an ICED AMERICANO over the counter at the coffee shop just up the road.' The guy chuckles and replies 'Yeah, that loser doesn't know good coffee from crappuccino. What about it?' 'Well, maybe your cell phone would like to try it.' you say, and you throw all 3 drinks at the guy, getting his cell phone wet and electrocuting him! Oh man! What are you gonna do? Well, first you check his wallet for choins, then you run like hell."
        data.choins += random.randrange(35,65,5)
        map[20].no_code()
this_scene = Scene(index,exits,description,revisit_desc,this_action_20)
map.append(this_scene)

# Town 1 Apartments - GF
index = 21
exits = {'WEST':15,'TALK':22}
description = "You're in your ex-girlfriend's apartment. She's sitting on the couch after having let you in hesitantly."
revisit_desc = "You're in your girlfriend's apartment."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Apartments - GF Talk
index = 22
exits = {'BACK':21}
description = "She sits there waiting for you to do something with your life, $name, you loser."
revisit_desc = "You're sitting across from your girlfriend."
def this_action_22(self):
    if data.event[3] == 0:
        data.event[3] = 1
        print "\nYou sit down in a chair across from her. She's obviously drunk. She opens her mouth to speak, mumbles to herself a second, and then says 'Remember the day we met?' You pause for a second, but she starts up before you can talk again. 'Didn't you smash down my door, give Dudley a pig tail, and tell me I'm a wizard?' You stare at her like she's crazy, which she is. You glance at the window, and when you look back at her she's asleep. Her sleepiness reminds you of how tired you are, so you take a nap too.\n\nYou wake up hours later. She's still sitting there, but she's awake now and looks frustrated. 'God I have a horrible hangover.' You sigh. You know what's coming. 'Can you make me some coffee? And I mean the good stuff - a - a - a CINNA-SMACH!' 'WHAT THE HELL ARE YOU TALKING ABOUT?' You yell at her. 'Oh yeah, you can't make tasty coffee drinks. That's why I dumped you. Well, it just so happens that the swarthy Italian barista I dated the other night left his recipes in the pair of boxers he left here, so you can use those to fix me some coffee. And YOU HAD BETTER DO WELL. I still have those pictures from prom night!"
        add_recipe('CINNA-SMACH','CINNAMON SYRUP','CAPPUCCINO',3)
        add_recipe('BLOODY LARRY','BERRY SYRUP','ESPRESSO',3)
        add_recipe('ROLO POLO','CARAMEL SYRUP','MOCHA',3)
    elif data.event[3] == 1:
        if itemnum('CINNA-SMACH') > 0:
            data.event[3] = 2
            map[22].no_code()
            data.choins += random.randrange(30,60,5)
            print "\nYou give her the drink and now she's off in a spicy land of magical cinnamon and coffee and such. In other words, she really likes it. You grab the pictures while she's having her happy time and throw them in the fireplace while she isn't looking. She satiated at the very least, and you have some new recipes. 'Why don't you sell those drinks out on the street? They suck less than you do. A LOT less...' she says, taking another sip. To prove her point, she throws some choins your way and then makes a weird wide-eyed sideways nod like she wants you to go away."
            rem_item("CINNA-SMACH",1)
        else:
            print "\n'Hurry back with my drink you loser.'"
this_scene = Scene(index,exits,description,revisit_desc,this_action_22)
map.append(this_scene)

# Town 1 Park
index = 23
exits = {'EAST':17,'NORTH':24,'WEST':28,'SOUTH':51}
description = "You're in the garden area of the big downtown park. Half of the town square's fountain extends into the grass and flowery area here and paths lead off into several directions."
revisit_desc = "You're in the garden near downtown."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Park - North Path
index = 24
exits = {'SOUTH':23}
description = "There's a small child here wearing a giant nametag that says 'TJG92'. He won't respond to you and he looks tired like he has been impersonating a programmer all night."
revisit_desc = "You're at a blocked path in the park."
def this_action_24(self):
    if itemnum('ESPRESSO') > 0:
        print "\nThe kid grabs the ESPRESSO out of your hand wildly and yells 'THIS IS RELEVANT TO MY INTERESTS!' and downs the entire drink in one gulp. He starts running around and bouncing and crap, and now he is no longer blocking the path like a sleeping giant monster that requires an otherwise useless flute to wake up. Bit I digress. The kid bounces off first to the northeast and you hear a buzz and a snap and see what appears to be lightning shoot into the air. You can only assume that he has destroyed some sort of transformer and now the electrified fence near the railroad tracks has been de-electrified. Then you see the kid soaring through the air to the south in the direction of your ex-girlfriend's apartment building, most likely to get his next caffiene fix."
        map[24].no_code()
        map[24].set_desc("There used to be a tired kid here, but now there are just park trails leading north and south. And the trees have bite marks all over them... hmm.")
        rem_item('ESPRESSO',1)
        map[9].add_opt("NORTH",33)
        map[24].set_desc("You're at a path in the park. It's not blocked.",1)
        map[24].add_opt("NORTH",25)
        map[21].add_opt("SOUTH",26)
        map[21].set_desc(map[21].description + " The apartment to the south is a bootleg coffee shop.")
        data.event[4] = 1;
this_scene = Scene(index,exits,description,revisit_desc,this_action_24)
map.append(this_scene)

# Town 1 Park - Cabin
index = 25
exits = {'SOUTH':24}
description = "You're at the door of a cabin in the northlands of the city park. A sign on the cabin wall says 'Animal Dentist'. The office is currently closed."
revisit_desc = "You're outside the animal dentist's cabin."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Apartments - Landon
index = 26
exits = {'NORTH':21,'ORDER':64}
description = "You're across the hall from your girlfriend's apartment at a coffee shop out of some guy's apartment. A crudely drawn sign says you're at 'Landon F's Coffee Emporium' and Landon comes out of the dark back room with his freshly hand-ground beans."
revisit_desc = "You're in Landon's apartment."
def this_action_26(self):
    if data.book.has_key("MOCHA") == 0:
        print "\n'PROTIP!' 'Huh?' you respond. 'PROTIP! COCOA MIX and COFFEE makes a MOCHA which is chocolatey and delicious!"
        add_recipe('MOCHA','COCOA MIX','COFFEE',1)
    else:
        r = random.randint(1,5)
        if r == 1:
            print "\nYou begin to comment on the cocoa mix packets, but then Landon sharpies over the Not For Resale label."
this_scene = Scene(index,exits,description,revisit_desc,this_action_26)
map.append(this_scene)

# Town 1 Night Club
index = 27
exits = {'NORTH':12,'TALK':48}
description = "You're in a night club. The music sucks, like a Coke can and a few Latin women inside a plane's engine room. In the corner, there's a raver girl with pink hair and piercings sitting at a table with a banner and various items. The banner says 'Tracey's Free Stuff'."
revisit_desc = "You're in a night club."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Park - Telescope
index = 28
exits = {'EAST':23,'SCOPE':29}
description = "You're on top of a big hill near the garden in the park. The hill is completely devoid of trees, and it seems as though someone left a telescope up here. It's tripod is planted firmly to the ground and the adjustment levers are a bit funky to say the least."
revisit_desc = "You're at the telescope."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Park - Telescope - Use
index = 29
exits = {'BACK':28}
description = "You finish using the telescope and set it back to 0 degrees."
revisit_desc = "You're right up close to the telescope."
def this_action_29(self):
    print "\nYou turn the telescope toward the red light district, then focus in further down the street and see one of those unnecessarily tall truck stop signs jutting into the air. It advertises showers, gas, apple pie, and COFFEE."
    if data.event[5] < 1:
        map[12].add_opt("EAST",30)
        data.event[5] = 1
this_scene = Scene(index,exits,description,revisit_desc,this_action_29)
map.append(this_scene)

# Town 1 Outside Diner
index = 30
exits = {'WEST':12,'NORTH':31,'EAST':39}
description = "You're in the middle of a busy part of town with fast cars and even faster food. The freeway on-ramp is to the south, to the east is the end of the road and a convenience store, and to the North is a truck stop."
revisit_desc = "You're in the busy area downtown."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Diner
index = 31
exits = {'SOUTH':30,'TALK':32}
description = "You're in a truck stop. Truckers sit at the bar, or at tables in small groups chuckling over COFFEE or eating various suspicious foods and big slices of cherry pie. A waitress named Flo makes her rounds at the tables and behind the counter taking orders to the cook in back."
revisit_desc = "You're in the truck stop."
def this_action_31(self):
    if data.event[7] == 0:
        print "\nYou overhear a conversation between a couple truckers.\n'Yeah, I'm stuck here until I get my CB radio fixed. Flo knows a guy up in the town northwest of here that's gonna fix it, but the bridge to get there is out and the only other way is a 5 hour detour.'"
        data.event[7] = 1
this_scene = Scene(index,exits,description,revisit_desc,this_action_31)
map.append(this_scene)

# Town 1 Diner - Talk
index = 32
exits = {'BACK':31}
description = "You're done at the counter for now."
revisit_desc = "You're at the truck stop counter."
def this_action_32(self):
    go_shop(4,"'Hi there hun, my name is Flo and I run this here diner and truck stop.|We serve all kinds of people and we even got a fancy pants bathroom with showers and all.|We even got all kinds of trucker stuff. Why don't you check out our shop, hun?'")
this_scene = Scene(index,exits,description,revisit_desc,this_action_32)
map.append(this_scene)

# Town 1 Rail Tracks
index = 33
exits = {'SOUTH':9,'EAST':34}
description = "You're on a set of railroad tracks along the north border of the town, leading east and west. There's a train bridge to the west, but you can walk along the tracks to the east."
revisit_desc = "You're at the train tracks."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Outside Mandi's
index = 34
exits = {'WEST':33,'SOUTH':35,'UP':42}
description = "You're at a weird looking combination train station and coffee shop called 'Mandi's Caffination Station'. There are tracks leading west, a platform leading up, and to the south is the inside of the shop and station."
revisit_desc = "You're outside Mandi's shop."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Mandi
index = 35
exits = {'NORTH':34,'DOWN':36,'TALK':38}
description = "You're inside 'Mandi's Caffination Station'. Weird looking people adorn the shop like decapitated dolls on a Christmas tree. The freaks come in all shapes and sizes, from monochrome goths to rainbow tinted witches. There's a wooden counter alongthe side of the shop selling various items as well as hand-cart rentals for the tracks outside. Stairs lead down to a restricted part of the shop."
revisit_desc = "You're in Mandi's caffination Station."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Mandi - Basement
index = 36
exits = {'UP':35,'PANEL':37}
description = "You're in a small control room underneath 'Mandi's Caffination Station'. The room is half caved in, as if the shacklike building above was built atop the rubble of an abandoned station. The room is half steampunk style and half 'look at me I played Myst in 1993' style. There is a set of 9 buttons on the wall in a 3 by 3 square with labels A through C across the top and 1 through 3 along the left."
revisit_desc = "You're in the control room."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Mandi - Basement - Panel
index = 37
exits = {'BACK':36}
description = "You finish pushing buttons and step back from the panel."
revisit_desc = "You're at a control panel."
def this_action_37(self):
    print "\nChoose a button to press in (column)(row) format, or X to stop monkeying around."
    button = ""
    while button != "X":
        # Get the button the player wants to push, and strip spaces and the words PRESS and PUSH if necessary
        button = get_input(1).lstrip('PRESUH ')
        if button == "X":
            break
        if len(button) != 2:
            print "\nI'm not sure which button would wanted to press."
        else:
            row = int(button[1:2])-1
            col = ord(button[0:1])-ord('A')
            if 0 <= row <= 2 or 0 <= col <= 2:
                # Trick Map
                square = data.maps[1][row][col]
                if 0 < square < 5:
                    square = (square % 4)+1
                elif 4 < square < 7:
                    square = 11 - square
                data.maps[1][row][col] = square
                # Real Map
                square = data.maps[0][row][col]
                if 0 < square < 5:
                    square = (square % 4)+1
                elif 4 < square < 7:
                    square = 11 - square
                data.maps[0][row][col] = square
                print "\nYou push the button marked %s and hear clicking noises somewhere." % (button)
            else:
                print "\nI'm not sure which button would wanted to press."
this_scene = Scene(index,exits,description,revisit_desc,this_action_37)
map.append(this_scene)

# Town 1 Mandi - Talk
index = 38
exits = {'BACK':35}
description = "You finish talking to Mandi and step back from the counter."
revisit_desc = "You're at the counter in Mandi's shop."
def this_action_38(self):
    if data.event[6] == 0:
        print "'Hey there, I'm Mandi and I own this place!' says the girl at the counter. She's about to speak but you hear something bump under the counter. She reaches down and slaps something saying 'Shut up Chris!' and you hear a mumbled 'Sorry Mistress Mandi' from under the counter. 'Anyway, we serve a lot of drinks here but the carts only go up and down this stretch of tracks. The railroad company used to let us through their railyard in the west, but it's all screwed up thanks to a freakin tornado we had, and it's impossible to walk there cause the railbridge is dangerous on foot. Until we get that fixed, there's no way to get to the other towns. We do have a map of the area in question though, and we sell magical photocopies of it to anyone who wants one. Anywho, come back in a bit and we'll be open for business!"
        data.event[6] = 1
    elif data.event[6] == 1 and data.maps[0] == [[2,4,7],[6,2,3],[1,7,4]]:
        go_shop(5,"'Wouldn't you know it? The path to the other town is free to travel now!|I guess someone found some switches and fixed the tracks at the railyard.|Maybe now cart rental sales will heat up!'")
    else:
        go_shop(5,"Hi there, I'm Mandi!|I own this place!| ")
this_scene = Scene(index,exits,description,revisit_desc,this_action_38)
map.append(this_scene)

# Town 1 Convenience Store Lot
index = 39
exits = {'WEST':30,'EAST':40}
description = "You're in the parking lot of the local convenience store. Two shady looking guys stand outside swearing. Through the glass windows you can see a really fat guy working behind the counter and some lady in front ofthe counter carrying on a boring conversation with him."
revisit_desc = "You're outside a convenience store."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Convenience Store
index = 40
exits = {'WEST':39,'TALK':41,'TOAST':49}
description = "You're inside the convenience store. There's a lady talking to the clerk, who looks bored and fat. He seems shady though and might be able to do some business dealings with you."
revisit_desc = "You're in the convenience store."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Convenience Store - Sell
index = 41
exits = {'BACK':40}
description = "You're at the convenience store counter blocking a convo between the fat guy and the crazy woman."
revisit_desc = "You're at the convenience store counter."
def this_action_41(self):
    print "\n'Hey buddy, I'm freakin bored. Our weekly shipment didn't come in. If there's any stuff you wanna sell me, make an offer and we'll see how it goes. I might be able to throw some choins your way for items you have.' What do you want to sell? (X to stop.)"
    sellthings()
this_scene = Scene(index,exits,description,revisit_desc,this_action_41)
map.append(this_scene)

# Town 1 Ticket Counter
index = 42
exits = {'DOWN':34,'TALK':43}
description = "You're on a raised train platform where hand carts are rented out for use on the old tracks. A ticket taker mans a make shift gate to keep hooligans from getting in without a rental pass. Stairs lead down to the other set of tracks near the caffination station, and behind the gate, tracks for the carts go west."
revisit_desc = "You're on a raised train platform."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Ticket Counter - Talk
index = 43
exits = {'BACK':42}
description = "You're at the ticket counter of the station next to Mandi's Caffination Station."
revisit_desc = "You're at the ticket counter."
def this_action_43(self):
    print "\n'Howdy %s, I'm Adam, the ticket-taker, psychic, and Mandi's sister." % (data.player_name),
    if data.event[6] <= 1:
        print "It's no use using these carts. They just go back and forth, and you don't look simple enough to find any fun in that.'"
    elif data.event[6] == 2:
        if itemnum("CART RENTAL") > 0:
            print "I see you have a CART RENTAL. I honestly don't see the need to keep buying them - I mean, hardly anyone buys these things so one pass should last you for a while. I remember your face, so I'll let you through free for a while, or at least 'til I forget what you look like.'"
            map[42].add_opt("WEST",44)
            rem_item("CART RENTAL",1)
            data.event[6] = 3
        else:
            print "It looks like the railway to the next town is open. I'll be cool and let you thorugh as many times as you want, but you need to buy at least one CART RENTAL from my sister."
    elif data.event[6] >= 3:
        print "Head on through, and have fun!'"
this_scene = Scene(index,exits,description,revisit_desc,this_action_43)
map.append(this_scene)

# Town 1 Cart
index = 44
exits = {'EAST':42,'WEST':45}
description = "You're on a hand cart. To the west is the rail yard with tons of crazy track switches and curves and lots of crazy machinery. To the east is the station platform for Mandi's Caffination Station."
revisit_desc = "You're on a hand cart on the tracks near Mandi's Caffination Station."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Hermit
index = 45
exits = {'EAST':44,'TALK':46}
description = "You're in the hermit's shack southwest of the rail yard. The hermit is here mixing an empty metal bowl with a wooden spoon making clink-clink-clink noises."
revisit_desc = "You're in the hermit's shack."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Hermit - Talk
index = 46
exits = {'BACK':45}
description = "You finish talking to the hermit and he goes back to mixing his empty metal bowl with his wooden spoon."
revisit_desc = "You're at the hermit's table in his shack."
def this_action_46(self):
    if data.event[6] == 3:
        print "\nYou walk up the the hermit and say 'Hey, what's going on? I thought the tracks were supposed to lead to North West City!' The hermit stops stirring his empty bowl and slowly tilts his head up to look at you. His solemn expression suddenly turns into an overly happy/cheesy smile and he says 'Are you the telephone repair man?' 'Excuse me?' 'I been waitin' to get my phone fixed for a long time. Could you fix it for me? I let you have my phone card if you get my phone line fixed. That way I don't need to hike all the way to the pay phone to make a call for more more wooden spoons and metal bowls. Just get some new WIRE and some ELECTRICAL TAPE and it's an easy job.'"
        map[25].set_desc("You're at the door of a cabin in the northlands of the city park. A sign on the cabin wall says 'Animal Dentist'. The office is now open.")
        map[25].add_opt("NORTH",50)
        map[21].add_opt("DOWN",52)
        data.event[6] = 4
    elif data.event[6] == 4:
        if data.event[8] == 3:
            if itemnum("ELECTRICAL TAPE") == 1 and itemnum("COPPER WIRE") == 1:
                print "\nYou look around for the phone and find it on a table in the corner. You find a small broken piece of cord wih markings on it like it was hit repeatedly with a wooden spoon. You use the electrical tape and braces and crudely splice together the wires and listen on the phone until you achieve a dial tone. 'Thanks' says the hermit, handing you the phone card. 'Now if you do me one more favor, I'll fix the train tracks so you can go to North West City. All I need now is a LOVE POTION. Can you find one for me?' You reluctantly agree."
                data.event[8] = 4
                add_item('PHONE CARD',1)
                rem_item('COPPER WIRE',1)
                rem_item('ELECTRICAL TAPE',1)
            else:
                print "\n'You get my phone fixed yet?' the hermit asks. 'Bring WIRE and ELECTRICAL TAPE.'"
        elif data.event[8] == 4:
            if itemnum("PSYCH WARD") == 1:
                print "\n'Wow, thanks for all your help young man! I have the switch for the rail yard tracks outside right over here. As soon as you leave I'll make sure you're out there after the switch and flip it the right way. Have fun in North West City!' The hermit says. He downs the 'love potion' and starts going crazy, as the actual name 'PSYCH WARD' would suggest. As you leave, you see broken wooden spoons and splinters of wood flying through the air with dented metal bowls. You sure hope he can fix the track..."
                data.event[8] = 5
                rem_item('PSYCH WARD',1)
                map[44].rem_opt('WEST')
                map[44].add_opt('WEST',47)
            else:
                print "\n'You get my love potion yet?' the hermit asks."
this_scene = Scene(index,exits,description,revisit_desc,this_action_46)
map.append(this_scene)

# Town 2 Station
index = 47
exits = {'EAST':44,'NORTH':57}
description = "You're at the abandoned 6th street station in North West City. Dusty windows and and broken wooden doors make the station look even older. Abandoned boxcars and hand carts line the tracks. A rusty old metal gate leads  up a ramp north to street level."
revisit_desc = "You're at the 6th street station."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Night Club - Tracey
index = 48
exits = {'BACK':27}
description = "You're in front of Tracey's table of free stuff. She's dancing to the music saying things like 'Yeah! Proper phat tunes man!' There's a sign on the table that says 'Stuff's all gone. Unlucky Kentucky!'"
revisit_desc = "You're at Tracey's Free Stuff table."
def this_action_48(self):
    print "\nYou walk up to Tracey's table and she turns and smiles and you and says 'Ave it! Ave it all!' in a British accent. She pushes all manner of free items at you including several BEAN and lots of COFFEE."
    a = random.randint(5,7)
    add_item('COFFEE',a)
    add_item('BEAN',a)
    a *= 2
    while a < 15:
        b = random.randint(1,15-a)
        add_item(random.choice(['MILK','SUGAR','ICE','WATER','CANDY','AMERICANO','CAPPUCCINO']),b)
        a += b
    map[48].no_code()
this_scene = Scene(index,exits,description,revisit_desc,this_action_48)
map.append(this_scene)

# Town 1 Convenience Store - Toast
index = 49
exits = {'BACK':40}
description = "You finish using the toaster oven and back away in case it decides to catch fire."
revisit_desc = "You're at the convenience store toaster oven."
def this_action_49(self):
    a = 1
    while a == 1: a = toast()
this_scene = Scene(index,exits,description,revisit_desc,this_action_49)
map.append(this_scene)

# Town 1 Park - Cabin - Inside
index = 50
exits = {'SOUTH':25}
description = "You're inside the animal dentist's office. The dentist sits in a big Victorian style chair in front of the fireplace smoking a pipe. The chair is a deep blood red color and tackily matches the metal and pleather 80s style waiting room chairs. A big wooden door to the west leads to the off-limits operating room where the dentist does his business. To the south is the door leading outside."
revisit_desc = "You're inside the animal dentist's office."
def this_action_50(self):
    if data.event[6] == 4 and data.event[8] == 0:
        print "\nThe dentist is a man in his mid 20s and has short brown hair and a mustache and goatee. He gets up from his chair by the fireplace and says 'Hi there, how can I help you?' You explain your need for wire briefly and he responds. 'I had a bit of copper wire recently, but I had to make braces for a squirrel. He should be done with them by now. If you can lure him in, I should be able to take them off and give you the wire.'"
        data.event[8] = 1
    elif data.event[8] == 2 and itemnum("NUTTY COFFEE") > 0:
        print "\nYou lure the squirrel into the office with the NUTTY COFFEE and help the dentist get it into the operating room. After a 10 minute wait in the reception area, the doctor emerges looking beat-up and exhausted with scratches all over his arms and chest, but with a jumble of copper wire in his hand for you. After taking the wire, you help the dentist to his chair by the fireplace and he promptly slumps over and passes out."
        data.event[8] = 3
        add_item("COPPER WIRE",1)
this_scene = Scene(index,exits,description,revisit_desc,this_action_50)
map.append(this_scene)

# Town 1 Park - Mid South Path
index = 51
exits = {'NORTH':23,'SOUTH':53}
description = "You're in the park in an area with a light amount of trees. Various wild type animals abound here - the occasional bunny, birds, insects, and a few squirrels."
revisit_desc = "You're in the city park near some wild animals."
def this_action_51(self):
    if itemnum("NUTTY COFFEE") >= 1:
        data.event[8] = 2
        map[51].no_code()
this_scene = Scene(index,exits,description,revisit_desc,this_action_51)
map.append(this_scene)

# Town 1 Apartments - Aaron
index = 52
exits = {'UP':21}
description = "You're in the apartment of a total nerd. It's a basement studio apartment with a half-made bed and dirty clothes on the floor. There are manga posters and video game equipment everywhere. A note on the cluttered desk in the room says 'Gone fencing, bbl - Aaron'."
revisit_desc = "You're in Aaron's apartment."
def this_action_52(self):
    if itemnum("TREE MAP") == 0:
        print "\nYou scrounge the studio apartment and find a roll of electrical tape next to a book called 'Gamebox Modding for Losers'. You also find a weird RPG style map labeled TREE rolled up next to a stack of role playing books. You snag the items."
        add_item("TREE MAP",1)
        add_item("ELECTRICAL TAPE",1)
        map[52].no_code()
this_scene = Scene(index,exits,description,revisit_desc,this_action_52)
map.append(this_scene)

# Town 1 Park - South Path
index = 53
exits = {'NORTH':51,'PANEL':54}
description = "You are in the south end of the city park where the trees are older and bigger and the light is scarce and the land is dark. The path here ends in a small clearing with a bit of light gleaming down. It continues back north toward the main park. There are 4 buttons on a panel on the side of a tree here."
revisit_desc = "You're in the south end of the park."
def this_action_53(self):
    if data.event[8] == 1 and itemnum("NUTTY COFFEE") > 0:
        data.event[8] = 2
this_scene = Scene(index,exits,description,revisit_desc,this_action_53)
map.append(this_scene)

# Town 1 Park - South Path - Panel
index = 54
exits = {'BACK':53}
description = "You finish tinkering with the panel and step back."
revisit_desc = "You're at a panel in the tree."
def this_action_54(self):
    print "\nTo press a button, enter 1, 2, or 3. Enter 0 to exit."
    cmd = 4
    while cmd != 0:
        cmd = get_input(2)
        if 1 <= cmd <= 3:
            data.maps[2][cmd-1].append(data.maps[2][cmd-1][0])
            del data.maps[2][cmd-1][0]
            print "\nYou press the button marked",cmd,
            if treemap == [[2,5,3,2,4],[6,2,7,7,3],[6,1,4,1,4]]:
                map[53].rem_opt('PANEL')
                map[53].add_opt('WEST',55)
                print "and hear a loud humming buzzing noise and the panel regresses into the tree and a door slides open behind you in another tree."
            else:
                print "and see an arrow pointing left light up next to the button, hear a buzz, and then the light goes off."
        else:
            print "\nYou smash your hand into the tree trying to push a button that isn't there."
this_scene = Scene(index,exits,description,revisit_desc,this_action_54)
map.append(this_scene)

# Town 1 Tree Elves
index = 55
exits = {'EAST':53,'TALK':56}
description = "You're in a great big hall full of Tree Elves scurrying around. Most of them are drinking coffee but you smell rum in the air too, as well as caramel. It smells like someone rubbed vanilla bean lotion on a pirate at a coffeehouse basically. The elves are chatting and having a good time and making wooden swords and scribbling on pads of parchment all over the place."
revisit_desc = "You're in the Tree Elves' Great Hall."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Tree Elves - Link
index = 56
exits = {'BACK':55}
description = "You're at a table talking to one of the drunken Tree Elves."
revisit_desc = "You're at one of the elves' tables."
def this_action_56(self):
    map[56].no_code()
    print "\nYou walk up to a Tree Elf to talk to him. He's extremely drunk - his disheveled green hat sits lopsided on his blonde hair and he's struggling to hammer a wooden sword into shape. He smells strongly of rum and seems to have wet himself. He looks up and is about to say something to you but then he passes out. When his face hits the table, a few pieces of parchment fall to the floor. You pick them up for him and, noticing a recipe for NUTTY COFFEE on top, copy it into your recipebook before letting the elf sleep."
    add_recipe("NUTTY COFFEE","COFFEE","NUTS",2)
this_scene = Scene(index,exits,description,revisit_desc,this_action_56)
map.append(this_scene)

# Town 2 Main 6th
index = 57
exits = {'SOUTH':47,'NORTH':58}
description = "You're on 6th and Main streets. The road is crumbling to pieces and hasn't been fixed in years. A few rusted old cars line the street inside the concrete barriers blocking travel through this stretch of road. A small gap in the barrier allows travel north to 7th and Main, and the rickety old train station gates are a stones throw to the south."
revisit_desc = "You're on 6th and Main streets."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 2 Main 7th
index = 58
exits = {'SOUTH':57,'NORTH':59}
description = "You're on the corner of 7th and Main. The road south is blocked off by barricades and leads to the crumbly and deteriorated intersection of 6th and Main. The road here isn't as bad but the traffic signal has some broken lights and there are some seedy looking individuals lurking about. To the north is the busier 8th and Main intersection, and to the east and west lie more of 8th street and abandoned shops."
revisit_desc = "You're on 7th and Main streets."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 2 Main 8th
index = 59
exits = {'SOUTH':58,'WEST':60,'EAST':63,'NORTH':68}
description = "You're on 8th and Main where the traffic is busy and people walk all around the sidewalks. Various ethnic shops are open up and down 8th street to the east and west and Main leads north and south to 9th and 7th streets, respectively."
revisit_desc = "You're on 8th and Main streets."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 2 West 8th
index = 60
exits = {'EAST':59,'NORTH':61}
description = "You're on West 8th street. Busy people hustle and bustle up and down the street and ethnic food shops line the street. To the north is a shop called 'La Casa de La Mesa'. The road to the west seems uninteresting, but Main street is to the east."
revisit_desc = "You're on West 8th street."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 2 Casa
index = 61
exits = {'SOUTH':60,'ORDER':62}
description = "You're inside La Casa de la una Mesa, which translates to 'The House of the One Table'. It's a Mexican food shop selling bootlegged cola made with cane sugar as well as various exotic and not-approved-by-government-standards coffee and chocolate products. The shop is also a coffee house, but only has a single table. No one sits at the table; everyone simply leans up against the wall sipping drinks and chatting. The door to the south exits to 8th street."
revisit_desc = "You're inside La Casa de la Una Mesa."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 2 Casa - Order
index = 62
exits = {'BACK':61}
description = "You finish your order and go lean up against a wall."
revisit_desc = "You're leaning against a wall at La Casa de la Una Mesa."
def this_action_62(self):
    go_shop(6)
this_scene = Scene(index,exits,description,revisit_desc,this_action_62)
map.append(this_scene)

# Town 2 East 8th
index = 63
exits = {'WEST':59,'EAST':65}
description = "You're on East 8th street. The road is squashed into one lane by swarms of people and carts as an impromptu farmers' market commences. Various carts sell various things peddling to individuals as well as business owners at the nearby restaurants and shops. Shops line the street to the north and south and Main street is to the west. You catch a glimpse of a set of stairs going down in a kiosk to the east."
revisit_desc = "You're on East 8th street at the market."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 1 Apartments - Landon Order
index = 64
exits = {'BACK':26}
description = "You're at the makeshift counter at Landon's apartment."
revisit_desc = "You're at the makeshift counter at Landon's apartment."
def this_action_64(self):
    go_shop(3)
this_scene = Scene(index,exits,description,revisit_desc,this_action_64)
map.append(this_scene)

# Underground Path - Town 2 Entrance
index = 65
exits = {'WEST':63,'DOWN':66}
description = "You're inside a kiosk with a sign saying 'Underground Path to North Beach' rotating above it in faded 80's style lettering. The street to the west is full of shops and vendors in a huge market. Stairs lead down to the underground path."
revisit_desc = "You're in the underground path entrance kiosk on 8th street."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Underground Path - Part 1
index = 66
exits = {'UP':65,'NORTH':67}
description = "You're in the underground path just under 8th street. The underground path leads north to North Beach and people walk downstairs from 8th street, which is just up from here."
revisit_desc = "You're in the underground path just under 8th street."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Underground Path - Part 2
index = 67
exits = {'NORTH':69,'SOUTH':66}
description = "You're in the underground path somewhere under North West City, with more of the path leading north and south. People walk up and down the path while a few rest on benches. Small trails of old rainwater curl around the concrete and into a storm drain."
revisit_desc = "You're in the underground path somewhere under North West City."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Town 2 - Main near 9th Street
index = 68
exits = {'SOUTH':59}
description = "You're on Main between 8th and 9th streets. Lots of people are outside cheering and running and dancing and having fun. They're celebrating the annual knife festival. The road to the north is blocked by a giant knife taking up the entire street while crews work feverishly to lift it up using ropes and equipment. Someone sure didn't think this through..."
revisit_desc = "You're on Main between 8th and 9th streets at the knife fesitval."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Underground Path - Part 3
index = 69
exits = {'NORTH':70, 'SOUTH':67}
description = "You're in the underground path somewhere under North West City, with more of the path leading north and south. People walk up and down the path, some of them wearing bathing suits, others resting on old wooden benches with chipped paint."
revisit_desc = "You're in the underground path somewhere under North West City."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# Underground Path - Part 4
index = 70
exits = {'SOUTH':69,'NORTH':71}
description = "You're in the underground path under the northernmost part of North West City. Light shines into the path's entrance to the north, but to the south along the path, the fluorescent lighting reigns supreme."
revisit_desc = "You're in the underground path in the north of North West City."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

# The Beach Outside the Path
index = 71
exits = {'SOUTH':70}
description = "You're on the beach at the cavern-like entrance to the underground path. The path runs southward underneath the bulk of North West City."
revisit_desc = "You're at the beach's entrance to the underground path."
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

index = 72
exits = {}
description = ""
revisit_desc = ""
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

index = 73
exits = {}
description = ""
revisit_desc = ""
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

index = 74
exits = {}
description = ""
revisit_desc = ""
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

index = 75
exits = {}
description = ""
revisit_desc = ""
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

index = 76
exits = {}
description = ""
revisit_desc = ""
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

index = 77
exits = {}
description = ""
revisit_desc = ""
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)

index = 78
exits = {}
description = ""
revisit_desc = ""
this_scene = Scene(index,exits,description,revisit_desc)
map.append(this_scene)