# Created by David Millar
# Last Modified October 21, 2007

import random
from staticcode import *
from data import data

# Random phrases for certain areas and the list of streets for each town
streetphrases = ["A group of hippie type people walks through the street.",
                 "Kids on the sidewalk play around near trees and mailboxes.",
                 "A couple holding hands walks slowly down the street with coffee.",
                 "Skateboarders do tricks through the street.",
                 "A lone well-dressed businessman walks down the street with his coffee, constantly checking his watch."]
town_a_streets = [2,4,5,9,12,15,17,30,39]
town_b_streets = [47,57,58,59,60,63]
        
def tjg_bounce():
    if data.event[4] == 1:
        print "\nTJG bounces into the area, causing mayhem and misfortune and destructively taking bites out of trees, rather than constructively taking a bite out of crime."
        
def street_talk():
    if data.CurSceneNum in town_a_streets:
        print "\n" + streetphrases[0]
        streetphrases.append(streetphrases[0])
        del streetphrases[0]

def exotic_cart():
    if (data.CurSceneNum in (town_a_streets + town_b_streets))\
    and data.exotic[0] < 1 and data.choins <= 150 and data.event[0] > 0:
        data.ishere = 1
        print "\nThe exotic coffee cart is here! Type EXOTIC to buy a product!"
        
def alertness():
    if data.exotic[0] > 0:
        found = random.randint(1,min(10,data.exotic[0]))
        data.exotic[0] -= found
        data.choins += found
        print "\nYour alertness from drinking that %s has made you more aware of your surrounds and you have found %d choins on the ground!" % (data.exotic[1], found)
        if data.exotic[0] == 0:
            print "...but now you've lost your buzz from the caffiene..."
            
encounters = {1: street_talk,
              2: street_talk,
              3: street_talk,
              4: street_talk,
              5: tjg_bounce,
              6: alertness,
              7: alertness,
              50: exotic_cart}

# Random Encounters
def random_encounter():
    rand_num = random.randint(1,50)
    data.ishere = 0
    if encounters.has_key(rand_num):
        encounters[rand_num]()