# Created by David Millar
# Last Modified October 27, 2007

import datetime

class world_class(object):
  pass

world = world_class()

# Store Menus
world.menus = [[[8,1,'COFFEE'],[3,1,'ICE'],[6,1,'BEAN'],[15,3,'BEAN']],
               [[10,1,'MILK'],[15,1,'CREAM']],
               [[4,1,'WATER'],[9,3,'WATER'],[12,1,'CANDY']],
               [[6,1,'COCOA MIX'],[30,6,'COCOA MIX'],[14,1,'ESPRESSO'],[50,5,'CANDY']],
               [[5,1,'COFFEE']],
               [[50,1,'RAIL MAP'],[20,1,'CART RENTAL'],[15,1,'BERRY SYRUP'],[13,1,'ESPRESSO']],
               [[10,1,'BEAN'],[15,5,'DARK CHOCOLATE']],
               []]

# Set the specialty coffee cart based on seasons
today = datetime.datetime.today()
# December
if today.month == 12:
    world.menus[7] = [[20,1,'GINGERBREAD CAPPUCCINO'],[35,1,'CRIMBO BREW'],[50,1,'SANKA CLAUS'],[100,1,'BOOTLEG-NOG']]
# Winter
elif 1 <= today.month <= 2:
    world.menus[7] = [[20,1,'GINGERBREAD CAPPUCCINO'],[35,1,'CAPPUCCINO SLUSHIE'],[50,1,'FIRESIDE CHAT'],[100,1,'HILL VALLEY COFFEE']]
# Spring
elif 3 <= today.month <= 5:
    world.menus[7] = [[20,1,'CAPPUCCINO JELLO SHOT'],[35,1,'WRATH OF OGOPOGO'],[50,1,'PEEPS N COCOA'],[100,1,'ORGANIC MEXICAN BLEND']]
# Summer
elif 6 <= today.month <= 8:
    world.menus[7] = [[20,1,'MUNICIPAL CAP-POOL-CCINO'],[35,1,'HEAT WAVE'],[50,1,'CAFE SOL'],[100,1,'RAY OF LIGHT']]
# Fall/Default
else:
    world.menus[7] = [[20,1,'BANANA BREAD CAPPUCCINO'],[35,1,'FUNKIN PUMKIN'],[50,1,'HARVEST EXPRESSO'],[100,1,'TRIPTO-FAN-DANGO']]
    
# Payphone locations
world.payphones = [4]
# Skill level descriptors for levels 1 to 4
world.skill = ['pretty easy','moderately difficult','quite hard','borderline insanely hard']
# Syrup Types Available via Blending Candy and Water
world.syrups = ['CARAMEL SYRUP','CINNAMON SYRUP','BERRY SYRUP','SUGAR']
# Map Tiles
world.tiles = [
' | |_ \___     ',
'  ___ /  _ | | ',
'___  _  \  | | ',
'_| | ___/      ',
'__________     ',
' | |  | |  | | ',
'_| |__   _ | | ']