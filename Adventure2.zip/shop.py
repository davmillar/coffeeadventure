# Created by David Millar
# Last Modified October 27, 2007

import readline, curses

from data import data
from world import world
from sys import stderr

from staticcode import *
from scene import *


# Display Menu
def go_shop(num, menumsg="Wanna buy something?|Take your pick.| "):
    displaylist = []
    menuitems = world.menus[num]
    for i in range(0, len(menuitems)):
        b = menuitems[i]
        displaylist.append(str(b[1]) + " x " + str(b[2]).ljust(30) + str(b[0]).rjust(3) + "ch")
        
    # Initialize the Popup
    try:
        menupop = Popup(59,17,"Here's Our Menu")
        menupop.show()
        linemsg = menumsg.split("|")
        for i in range(3):
            menupop.scr.addstr(1 + i, 2, linemsg[i])
        menupop.scr.addstr(6, 2,"You scan the menu for items that you want to buy.")
        menupop.scr.addstr(7, 2, "Use the arrow keys and enter to select.")
        
        menupop.init_menu(8, 2, displaylist)
        item_to_buy = 0
        while item_to_buy > -1:
            item_to_buy = menupop.use_menu()
            item_buying = menuitems[item_to_buy]
            menupop.scr.addstr(14, 2, " " * 45)
            menupop.scr.addstr(15, 2, " " * 45)
            if item_to_buy > -1:
                if num != 7:
                    maxallowed = (data.choins - (data.choins % item_buying[0])) / item_buying[0]
                    menupop.scr.addstr(14, 2, item_buying[2])
                    if maxallowed == 0:
                        menupop.scr.addstr(15, 2, "You can't afford any of that item.")
                        menupop.scr.getch()
                        buyamt = -1
                    else:
                        menupop.scr.addstr(15, 2, "How many? (Max " + str(maxallowed) + ")")
                        curses.echo()
                        tmpamt = menupop.scr.getstr(15, 23, 3)
                        if tmpamt.isdigit():
                            buyamt = int(tmpamt)
                        else:
                            buyamt = 0
                        curses.noecho()
                else:
                    buyamt = 1
                menupop.scr.addstr(14, 2, " " * 45)
                menupop.scr.addstr(15, 2, " " * 45)
                if (item_buying[0] * buyamt) <= data.choins and buyamt > 0:
                    data.choins -= (item_buying[0] * buyamt)
                    if num != 7:
                        add_item(item_buying[2],item_buying[1] * buyamt)
                        menupop.scr.addstr(14, 2, " " * 45)
                        menupop.scr.addstr(15, 2, "Hope you're happy with the " + item_buying[2] + ".")
                    else:
                        menupop.scr.addstr(14, 2, "Hope you're happy with the " + item_buying[2] + ".")
                        menupop.scr.addstr(15, 2, "You greedily gulp down the drink and feel more alert!")
                        data.exotic[0] = int(((random.random() * 1.5) + .25)*item_buying[0])
                        data.exotic[1] = item_buying[2]
                        item_to_buy = -1
                elif buyamt == 0:
                    menupop.scr.addstr(15, 2, "You can't buy that many.")
    finally:
        menupop.close()