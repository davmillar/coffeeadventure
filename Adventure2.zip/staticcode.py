# Created by David Millar
# Last Modified October 21, 2007

import os, readline, curses
from data import data
from world import world

# Popup class making use of curses 'windows' easier
class Popup:
    # Initiation Function
    def __init__(self,width,length,title=None):
        self.x = int((79 - width) / 2)
        self.y = int((23 - length) / 2)
        self.w = width
        self.l = length
        self.title = title
    # Show the window
    def show(self):
        stdscr = curses.initscr()
        curses.noecho()
        self.scr = stdscr.subwin(self.l,self.w,self.y,self.x)
        self.scr.box()
        if self.title:
            self.scr.addstr(0,2,"[ "  + self.title + " ]")
        self.scr.refresh()
    # Close the window
    def close(self):
        curses.echo()
        self.scr.erase()
        curses.endwin()
        clearscreen()
    # Create a horizontal rule (line)
    def hr(self,row):
        self.scr.hline(row,1,curses.ACS_HLINE,self.w - 2)
    # Initialize an up-down menu with 4 options and an exit option
    def init_menu(self,first_row,first_col,item_list):
        self.first_row = first_row
        self.first_col = first_col
        self.menu_list = item_list
        self.menu_list.append("Exit")
        self.scr.addstr(first_row, self.first_col, self.menu_list[0], curses.A_STANDOUT)
        for i in range(1, len(self.menu_list)):
            self.scr.addstr(i + first_row, self.first_col, self.menu_list[i])
    # Change Menu Items to New Menu
    def replace_menu(self,item_list):
        self.menu_list = item_list
        self.menu_list.append("Exit")
        self.scr.addstr(first_row, self.first_col, self.menu_list[0], curses.A_STANDOUT)
        for i in range(1, len(self.menu_list)):
            self.scr.addstr(i + first_row, self.first_col, self.menu_list[i])
    # Use the menu initialized above. This is typically used with a loop until player chooses Nothing
    def use_menu(self):
        selected = 0
        while 1:
            # Highlight Current Selection
            self.scr.addstr(selected + self.first_row, self.first_col, self.menu_list[selected], curses.A_STANDOUT)
            self.scr.refresh()
            # Get Key Press
            key = self.scr.getch()
            # Unhighlight Current Selection
            self.scr.addstr(selected + self.first_row, self.first_col, self.menu_list[selected])
            # Up Key
            if key == 65:
                selected -=1
                if selected == -1:
                    selected = len(self.menu_list) - 1
            # Down Key
            elif key == 66:
                selected += 1
                if selected == len(self.menu_list):
                    selected = 0
            # Enter Key
            elif key == 10:
                if selected == len(self.menu_list) - 1:
                    return -1
                else:
                    return selected

# Returns Number of That Item You Have
def itemnum(i):
    if data.inventory.has_key(i):
        return data.inventory[i]
    else:
        return 0

# Add Item
def add_item(i,n):
    if data.inventory.has_key(i):
        data.inventory[i] += n
        if data.inventory[i] > 999:
           data.inventory[i] = 999
    else:
        data.inventory[i] = n

# Take Item
def rem_item(i,n):
    data.inventory[i] -= n
    if data.inventory[i] <= 0:
        del data.inventory[i]

# Show Inventory
def show_inv():
    print "\nYou have the following items in your sack:\nTRUSTY MINI ALL-IN-ONE DRINK MAKER",
    ik = data.inventory.keys()
    ik.sort()
    a = 0
    for i in ik:
        a = 1 - a
        if a == 0:
            print " | ",
        else:
            print "\n",
        print i.ljust(29),"X",str(data.inventory[i]).rjust(3,'0'),
    print "\nCHOINS X",data.choins

# Get Valid Input (0 for anycase, 1 for uppercase, 2 for integer)
def get_input(case):
    tmp = ""
    while tmp == "":
        tmp = raw_input("--> ")
    if case == 1:
        tmp = to_upper(tmp)
    elif case == 2:
        if tmp.isdigit():
            return int(tmp)
        else:
            return 0
    return tmp

# Converts a string to upper case
def to_upper(string):
    upper_case = ""
    for character in string:
        if 'a' <= character <= 'z':
            location = ord(character) - ord('a')
            new_ascii = location + ord('A')
            character = chr(new_ascii)
        upper_case += character
    return upper_case

# Converts a string to lower case
def to_lower(string):
    lower_case = ""
    for character in string:
        if 'A' <= character <= 'Z':
            location = ord(character) - ord('A')
            new_ascii = location + ord('a')
            character = chr(new_ascii)
        lower_case += character
    return lower_case

# Clears the Screen
# If something goes awry it will just print 50 newlines to clear it as best as possible.
def clearscreen():
    if os.name == "posix":
        os.system("clear")
    elif os.name in ("nt", "dos", "ce"):
        os.system("CLS")
    else:
        print "\n" * 50

def credits():
    #Start Curses Screen
    ts = Popup(79,23)
    ts.show()
    # Title/About Screen Text
    ts.scr.addstr(1,2,"COFFEE ADVENTURE v" + data.version)
    ts.scr.addstr(2,2,"By David Millar")
    ts.scr.addstr(4,2,"An interactive fiction game about:")
    ts.scr.addstr(5,4,"Being a Barista, Mixing Drinks, Exploring the World, and Other Nonsense.")
    ts.scr.addstr(6,2,"You might think you're an ordinary person, but you're actually...")
    ts.scr.addstr(7,4,"A COFFEE WARRIOR!")
    ts.hr(9)
    ts.scr.addstr(11,2,"This game has been created from scratch in Python.")
    ts.hr(19)
    ts.scr.addstr(21,2,"davmillar@gmail.com")
    ts.scr.addstr(21,63,"thegriddle.net")
    ts.scr.refresh()
    cred = {"Inspiration":["Adam LeFevre","Amanda LeFevre","Aaron Evangelisti","Emily Bischoff"],
            "Development":["Killernurd","Simon Donkers","Charlie Nolan"],
            "Testing":["Workman 161","Lunar","Kidbomb","Joe"]}
    for group in cred.keys():
        ts.scr.addstr(13,2,group)
        a = 0
        for name in cred[group]:
            a += 1
            ts.scr.addstr(13+a,2,"- "+name)
        ts.scr.refresh()
        time.sleep(5)
        for i in range(0,5):
            ts.scr.addstr(13+i,2," "*40)
    ts.scr.addstr(13,2,"Press any key (enter) to continue with your game.")
    ts.scr.getch()
    ts.close()