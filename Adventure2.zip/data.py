# Created by David Millar
# Last Modified October 20, 2007

class data_class(object):
  pass

data = data_class()

data.version = ".102"

# Save filename
data.save_file = ""
# Player Name
data.player_name = ""
# Character Password
data.password = ""
# Current Scene Number
data.CurSceneNum = 0
# Events
data.event = [0,0,0,0,0,0,0,0,0]

data.exotic = [0,""]

# Event List
# 0 Farmer Brown     1 Shell Game/Date    2 Revenge on Prep    3 Girlfriend
# 4 TJG Espresso     5 Scope/Truck Stop   6 Railway/Mandi      7 CB Radio
# 8 Squirrel/Wire

# Maps in possession
data.maps=[[[1,1,7],[5,1,1],[1,7,1]],
[[7,1,1],[1,5,1],[1,1,7]],
[[3,2,4,2,5],[3,6,2,7,7],[4,1,4,6,1]]]
# Checks to see is the exotic coffee vendor is here
data.ishere = 0
# Map Changes to Be Saved in the Save File and Applied Later at Load Time
data.map_changes = []
# Inventory and Recipe Book
data.inventory = {'WATER':5}
data.choins = 50
data.book = {'COFFEE':[1,'BEAN','WATER']}